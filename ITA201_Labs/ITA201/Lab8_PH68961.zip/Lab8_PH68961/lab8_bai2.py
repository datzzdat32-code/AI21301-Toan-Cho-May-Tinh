"""
LAB 8 - BÀI 2: Chuyển đổi Bài toán Quy hoạch Tuyến tính về Dạng Chính tắc (Standard Form)
Môn học: AI21301 - Toán cho học máy
"""

def convert_to_standard_form(c, A_ub, b_ub):
    """
    Chuyển bài toán Quy hoạch Tuyến tính (LP) từ dạng bất đẳng thức sang dạng chính tắc:
    - Bài toán gốc: max c^T * x thỏa mãn A_ub * x <= b_ub, x >= 0
    - Dạng chính tắc: min c_std^T * x_new thỏa mãn A_eq * x_new = b_eq, x_new >= 0
      bằng cách đổi dấu hàm mục tiêu (max -> min) và thêm các biến bù (Slack variables) s_i >= 0.
      
    Parameters:
        c (list): Vector hệ số hàm mục tiêu gốc (kích thước n).
        A_ub (list of list): Ma trận hệ số ràng buộc bất đẳng thức (kích thước m x n).
        b_ub (list): Vector vế phải ràng buộc (kích thước m).
        
    Returns:
        tuple: (c_std, A_eq, b_eq)
    """
    m = len(A_ub)  # Số ràng buộc
    n = len(c)     # Số biến gốc ban đầu
    
    # 1. Đổi dấu hàm mục tiêu max -> min: c_std = -c và hệ số biến bù bằng 0.0
    c_std = [-val for val in c] + [0.0] * m
    
    # 2. Xây dựng ma trận A_eq mở rộng với ma trận đơn vị I_m tương ứng cho m biến bù
    A_eq = []
    for i in range(m):
        slack_row = [1.0 if j == i else 0.0 for j in range(m)]
        A_eq.append(A_ub[i] + slack_row)
        
    # 3. Vector vế phải
    b_eq = list(b_ub)
    
    return c_std, A_eq, b_eq


# Chạy thử nghiệm với test case mẫu
if __name__ == "__main__":
    c = [40, 30]
    A_ub = [
        [2, 1],
        [1, 1]
    ]
    b_ub = [100, 80]

    c_std, A_eq, b_eq = convert_to_standard_form(c, A_ub, b_ub)
    
    print("Hàm mục tiêu c_std (dạng min):", c_std)
    print("Ma trận ràng buộc đẳng thức A_eq:")
    for row in A_eq:
        print(row)
    print("Vector vế phải b_eq:", b_eq)
    
    # Kết quả kỳ vọng:
    # c_std: [-40, -30, 0.0, 0.0]
    # A_eq: [[2, 1, 1.0, 0.0], [1, 1, 0.0, 1.0]]
    # b_eq: [100, 80]
