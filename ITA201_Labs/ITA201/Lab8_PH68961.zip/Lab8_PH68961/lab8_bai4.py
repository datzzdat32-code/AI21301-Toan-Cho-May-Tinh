"""
LAB 8 - BÀI 4: Thuật toán Tối ưu Gradient Descent 1D Cơ bản (Bước đệm sang Deep Learning)
Môn học: AI21301 - Toán cho học máy
"""

def gradient_descent_1d(initial_w, learning_rate, epochs):
    """
    Thuật toán Gradient Descent 1D tìm cực tiểu của hàm mất mát phi tuyến:
    L(w) = w^2 - 4*w + 4 = (w - 2)^2
    Đạo hàm (Gradient): L'(w) = 2*w - 4
    
    Quy tắc cập nhật:
    w_new = w - learning_rate * L'(w)
    
    Parameters:
        initial_w (float): Trọng số khởi tạo ban đầu.
        learning_rate (float): Tốc độ học (learning rate).
        epochs (int): Số bước lặp tối ưu hóa.
        
    Returns:
        tuple: (optimal_w, loss_history)
            - optimal_w (float): Trọng số tối ưu sau quá trình huấn luyện.
            - loss_history (list): Lịch sử giá trị Loss qua các epoch.
    """
    w = initial_w
    loss_history = []
    
    print(f"--- BẮT ĐẦU GRADIENT DESCENT: w_init = {initial_w}, lr = {learning_rate}, epochs = {epochs} ---")
    for epoch in range(1, epochs + 1):
        # 1. Tính giá trị hàm mất mát Loss tại trọng số hiện tại
        current_loss = w**2 - 4*w + 4
        loss_history.append(current_loss)
        
        # 2. Tính đạo hàm dL/dw
        grad = 2*w - 4
        
        # 3. Cập nhật trọng số
        w = w - learning_rate * grad
        
        if epoch % 5 == 0 or epoch == 1:
            print(f"Epoch {epoch:2d}: w = {w:.4f}, Loss = {current_loss:.4f}, Gradient = {grad:.4f}")
            
    final_loss = w**2 - 4*w + 4
    loss_history.append(final_loss)
    
    return w, loss_history


# Chạy thử nghiệm với test case mẫu
if __name__ == "__main__":
    w_init = 10.0
    lr = 0.1
    epochs = 20

    optimal_w, loss_hist = gradient_descent_1d(w_init, lr, epochs)
    
    print(f"\nKết quả sau {epochs} epochs:")
    print(f"Trọng số tối ưu w*: {optimal_w:.4f} (Kỳ vọng hội tụ về 2.0)")
    print(f"Giá trị Loss cuối cùng: {loss_hist[-1]:.6f} (Kỳ vọng hội tụ về 0.0)")
