"""
LAB 8 - BÀI 3: Xây dựng Bài toán Đối ngẫu (Dual Problem Formulation)
Môn học: AI21301 - Toán cho học máy
"""

def generate_dual_problem(c_primal, A_primal, b_primal):
    """
    Xây dựng bài toán Đối ngẫu (Dual Problem) từ bài toán Gốc (Primal):
    - Bài toán gốc (Primal):
        max c^T * x thỏa mãn A * x <= b và x >= 0
    - Bài toán đối ngẫu (Dual):
        min b^T * y thỏa mãn A^T * y >= c và y >= 0
        
    Parameters:
        c_primal (list): Vector hàm mục tiêu bài toán gốc.
        A_primal (list of list): Ma trận ràng buộc bài toán gốc (m x n).
        b_primal (list): Vector vế phải bài toán gốc.
        
    Returns:
        tuple: (c_dual, A_dual, b_dual)
            - c_dual: Vector hàm mục tiêu đối ngẫu (= b_primal).
            - A_dual: Ma trận ràng buộc đối ngẫu (= A_primal^T).
            - b_dual: Vector vế phải đối ngẫu (= c_primal).
    """
    m = len(A_primal)
    n = len(A_primal[0])
    
    # 1. Vector hàm mục tiêu đối ngẫu: c_dual = b_primal
    c_dual = list(b_primal)
    
    # 2. Ma trận ràng buộc đối ngẫu: A_dual = A_primal^T (chuyển vị)
    A_dual = [[A_primal[i][j] for i in range(m)] for j in range(n)]
    
    # 3. Vector vế phải đối ngẫu: b_dual = c_primal
    b_dual = list(c_primal)
    
    return c_dual, A_dual, b_dual


# Chạy thử nghiệm và kiểm chứng Định lý Đối ngẫu mạnh
if __name__ == "__main__":
    c_primal = [40, 30]
    A_primal = [
        [2, 1],
        [1, 1]
    ]
    b_primal = [100, 80]

    c_dual, A_dual, b_dual = generate_dual_problem(c_primal, A_primal, b_primal)

    print("--- CÁC THÔNG SỐ BÀI TOÁN ĐỐI NGẪU (DUAL) ---")
    print(f"Hàm mục tiêu đối ngẫu (min) c_dual = {c_dual}")
    print("Ma trận ràng buộc A_dual (A^T):")
    for row in A_dual:
        print(row)
    print(f"Vector vế phải b_dual = {b_dual}")

    # Kiểm chứng Định lý Đối ngẫu mạnh (Strong Duality Theorem):
    # Cho nghiệm tối ưu gốc x* = (20, 60) và nghiệm đối ngẫu y* = (10, 20)
    x_star = (20, 60)
    y_star = (10, 20)

    primal_val = c_primal[0] * x_star[0] + c_primal[1] * x_star[1]
    dual_val = c_dual[0] * y_star[0] + c_dual[1] * y_star[1]

    print("\n--- KIỂM CHỨNG ĐỊNH LÝ ĐỐI NGẪU MẠNH ---")
    print(f"Giá trị mục tiêu gốc Primal (c^T * x*): {primal_val} USD")
    print(f"Giá trị mục tiêu đối ngẫu Dual (b^T * y*): {dual_val} USD")
    print(f"Khẳng định c^T * x* == b^T * y*: {primal_val == dual_val}")
    # Kết quả kỳ vọng: 2600 == 2600 (True)
