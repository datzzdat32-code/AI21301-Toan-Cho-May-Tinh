"""
LAB 8 - BÀI 5: Mô phỏng Tối ưu hóa Ràng buộc L1 (Lasso) vs L2 (Ridge) & Phân tích Điểm Kỳ dị
Môn học: AI21301 - Toán cho học máy
"""

import math

def loss_func(w1, w2):
    """Hàm mất mát MSE giả lập có tâm tại (3, 3): Loss = (w1 - 3)^2 + (w2 - 3)^2"""
    return (w1 - 3.0)**2 + (w2 - 3.0)**2


def solve_constrained_l1():
    """
    Mô phỏng ràng buộc L1 (Lasso Regularization): ||W||_1 = |w1| + |w2| <= 2
    Miền ràng buộc là một hình thoi với 4 đỉnh nằm trên trục tọa độ:
    (2, 0), (0, 2), (-2, 0), (0, -2).
    
    Returns:
        tuple: (best_w, min_loss, vertex_losses)
    """
    # 1. Đánh giá giá trị Loss tại 4 đỉnh kỳ dị của hình thoi L1
    vertices = [(2.0, 0.0), (0.0, 2.0), (-2.0, 0.0), (0.0, -2.0)]
    vertex_losses = {}
    for v in vertices:
        vertex_losses[v] = round(loss_func(v[0], v[1]), 4)
        
    # 2. Duyệt lưới các điểm dọc theo 4 cạnh biên của hình thoi |w1| + |w2| = 2
    best_w = None
    min_loss = float('inf')
    num_samples = 200
    
    # Đoạn 1: w1 từ 0 -> 2, w2 = 2 - w1
    for i in range(num_samples + 1):
        w1 = (2.0 * i) / num_samples
        w2 = 2.0 - w1
        l = loss_func(w1, w2)
        if l < min_loss:
            min_loss = l
            best_w = (round(w1, 4), round(w2, 4))
            
    return best_w, round(min_loss, 4), vertex_losses


def solve_constrained_l2():
    """
    Mô phỏng ràng buộc L2 (Ridge Regularization / Weight Decay):
    ||W||_2^2 = w1^2 + w2^2 <= 4  (Hình tròn tâm (0, 0), bán kính R = 2)
    
    Điểm tiếp xúc tối ưu trên đường tròn gần tâm sai số (3, 3) nhất
    nằm trên đường nối từ (0, 0) đến (3, 3) với góc theta = pi / 4 (45 độ):
    w1* = R * cos(pi/4) = 2 * (sqrt(2)/2) = sqrt(2) ~ 1.4142
    w2* = R * sin(pi/4) = 2 * (sqrt(2)/2) = sqrt(2) ~ 1.4142
    
    Returns:
        tuple: (optimal_point, min_loss)
    """
    # Tính tọa độ giải tích chính xác
    exact_w1 = math.sqrt(2)
    exact_w2 = math.sqrt(2)
    exact_loss = loss_func(exact_w1, exact_w2)
    
    # Duyệt kiểm chứng bằng quét góc theta từ 0 đến 2*pi
    best_theta = 0
    min_loss = float('inf')
    num_steps = 1000
    R = 2.0
    
    for i in range(num_steps):
        theta = (2 * math.pi * i) / num_steps
        w1 = R * math.cos(theta)
        w2 = R * math.sin(theta)
        l = loss_func(w1, w2)
        if l < min_loss:
            min_loss = l
            best_theta = theta
            
    num_w1 = R * math.cos(best_theta)
    num_w2 = R * math.sin(best_theta)
    
    return (round(num_w1, 4), round(num_w2, 4)), round(exact_loss, 4)


# ==============================================================================
# PHÂN TÍCH HÌNH HỌC: L1 (LASSO) vs L2 (RIDGE)
# ==============================================================================
# 1. Ràng buộc L1 và tính thưa (Sparsity - Feature Selection):
#    - Miền ràng buộc ||W||_1 <= C có dạng hình thoi (Diamond) với các "đỉnh nhọn" (Corners/Vertices)
#      nằm chính xác trên các trục tọa độ, nơi một trong các biến số bằng 0 tuyệt đối (w1 = 0 hoặc w2 = 0).
#    - Trong bài toán hồi quy Machine Learning thực tế, các đường đồng mức sai số là các hình elip nghiêng.
#      Khi mở rộng dần hình elip từ tâm nghiệm tối ưu tự do, vị trí tiếp xúc đầu tiên giữa đường mức elip
#      và hình thoi hầu như luôn va chạm vào một trong các đỉnh nhọn này.
#    - Khi tiếp xúc tại đỉnh trục tọa độ, trọng số ứng với biến không quan trọng bị triệt tiêu về 0 hoàn toàn,
#      giúp tự động loại bỏ đặc trưng dư thừa (Feature Selection) và tạo ra mô hình thưa (Sparse Model).
#
# 2. Ràng buộc L2 và suy giảm trọng số (Weight Decay):
#    - Miền ràng buộc ||W||_2^2 <= C là một đường tròn trơn (Smooth hypersphere), hoàn toàn đối xứng
#      và KHÔNG có các góc nhọn hay điểm kỳ dị trên trục tọa độ.
#    - Điểm tiếp xúc giữa đường đồng mức và đường tròn luôn xảy ra tại vị trí tiếp tuyến mịn (Smooth tangency),
#      cụ thể ở đây là điểm (sqrt(2), sqrt(2)) ~ (1.414, 1.414).
#    - Do đó, L2 chỉ thu nhỏ đều các trọng số về gần 0 (co cụm trọng số - Weight Shrinkage), giúp mô hình
#      ổn định trước nhiễu và tránh Overfitting, nhưng KHÔNG bao giờ ép hẳn một trọng số nào về 0 tuyệt đối.
#
# ==============================================================================
# TỔNG KẾT XUYÊN SUỐT 8 BÀI THỰC HÀNH MÔN HỌC (AI MATHEMATICS BLUEPRINT)
# ==============================================================================
# 1. LAB 1 & 2 (Đại số tuyến tính cơ bản):
#    - Vector, Ma trận, Phép nhân ma trận và Phép khử Gauss.
#    - Đóng vai trò là ngôn ngữ cốt lõi biểu diễn dữ liệu bảng, ảnh số, nhúng văn bản (Embedding)
#      và cơ chế truyền xuôi (Forward Pass) trong Mạng Nơ-ron: Y = W * X + b.
#
# 2. LAB 3 & 4 (Không gian Vector & Phân rã Ma trận PCA / SVD):
#    - Không gian con, Trị riêng (Eigenvalues), Vector riêng (Eigenvectors), và phép phân rã SVD/PCA.
#    - Là nền tảng để nén giảm chiều dữ liệu (Dimensionality Reduction), khử tương quan, và trích xuất
#      biểu diễn tiềm ẩn (Latent Space) trong các mô hình Generative AI hiện đại (VAE, Diffusion).
#
# 3. LAB 5 (Xác suất & Lý thuyết thông tin):
#    - Shannon Entropy, Information Gain (Decision Trees), Naive Bayes và Binary Cross-Entropy Loss.
#    - Là công cụ đo lường độ hỗn loạn (Uncertainty) và định nghĩa hàm mục tiêu mất mát (Loss Function)
#      chuẩn tắc để huấn luyện các bộ phân loại nhị phân và đa lớp.
#
# 4. LAB 6 & 7 (Lý thuyết Đồ thị & Luồng trong mạng):
#    - Ma trận kề, BFS/DFS, Liên thông, Flood Fill, Chuỗi Markov, PageRank và Luồng cực đại Ford-Fulkerson.
#    - Mô hình hóa cấu trúc mạng lưới quan hệ (Mạng xã hội, Kiến thức - Knowledge Graph), mạng nơ-ron đồ thị
#      (Graph Neural Networks - GNN) và bài toán ghép cặp tối ưu tài nguyên.
#
# 5. LAB 8 (Tối ưu hóa & Quy hoạch tuyến tính):
#    - Quy hoạch tuyến tính (LP), Đối ngẫu (Dual SVM), Regularization L1/L2 và Gradient Descent.
#    - Đóng vai trò là "trái tim" của Trí tuệ nhân tạo: Mọi mô hình Deep Learning cuối cùng đều là bài toán
#      tối ưu hóa hàm mất mát phi tuyến để tìm bộ trọng số W* tối ưu nhất thông qua lan truyền ngược (Backpropagation).
# ==============================================================================


# Chạy thử nghiệm với test case mẫu
if __name__ == "__main__":
    print("--- 1. MÔ PHỎNG RÀNG BUỘC L1 (LASSO) ---")
    best_l1, min_l1, v_losses = solve_constrained_l1()
    print("Giá trị Loss tại 4 đỉnh của hình thoi L1 (|w1| + |w2| <= 2):")
    for v, loss_val in v_losses.items():
        print(f" - Đỉnh {v}: Loss = {loss_val}")
    print(f"Hai đỉnh trên trục tọa độ (2, 0) và (0, 2) đạt Loss nhỏ nhất = {v_losses[(2.0, 0.0)]}")
    print(f"Nghiệm tiếp xúc đối xứng trên cạnh: {best_l1} với Loss cực tiểu = {min_l1}\n")

    print("--- 2. MÔ PHỎNG RÀNG BUỘC L2 (RIDGE) ---")
    best_l2, min_l2 = solve_constrained_l2()
    print(f"Nghiệm tiếp xúc tối ưu trên đường tròn L2 (w1^2 + w2^2 <= 4): {best_l2}")
    print(f"Giá trị Loss cực tiểu: {min_l2}")
    print(f"Kiểm chứng tọa độ: (sqrt(2), sqrt(2)) = ({math.sqrt(2):.4f}, {math.sqrt(2):.4f})")
