"""
LAB 8 - BÀI 1: Giải Bài toán Quy hoạch Tuyến tính 2D bằng Phương pháp Duyệt Đỉnh Hình học
Môn học: AI21301 - Toán cho học máy
"""

def solve_lp_geometric(vertices, c1, c2):
    """
    Tìm nghiệm tối ưu của bài toán quy hoạch tuyến tính 2D bằng phương pháp hình học:
    Theo định lý cơ bản của Quy hoạch tuyến tính, nếu bài toán có nghiệm tối ưu
    thì nghiệm tối ưu chắc chắn đạt được tại ít nhất một đỉnh (extreme point)
    của miền đa diện lồi chấp nhận được.
    
    Hàm mục tiêu: max f(x1, x2) = c1 * x1 + c2 * x2
    
    Parameters:
        vertices (list of tuple): Danh sách tọa độ các đỉnh của miền lồi [(x1, x2), ...].
        c1 (float): Hệ số của biến x1 trong hàm mục tiêu.
        c2 (float): Hệ số của biến x2 trong hàm mục tiêu.
        
    Returns:
        tuple: (best_vertex, best_val)
            - best_vertex (tuple): Tọa độ đỉnh đạt cực đại (x1*, x2*).
            - best_val (float): Giá trị hàm mục tiêu lớn nhất f*.
    """
    best_val = -float('inf')
    best_vertex = None
    
    print("--- DUYỆT TỌA ĐỘ CÁC ĐỈNH CỦA MIỀN ĐA DIỆN LỒI ---")
    for x1, x2 in vertices:
        # Tính giá trị hàm mục tiêu f = c1 * x1 + c2 * x2
        current_val = c1 * x1 + c2 * x2
        print(f"Đỉnh ({x1}, {x2}) -> Giá trị f = {current_val}")
        
        if current_val > best_val:
            best_val = current_val
            best_vertex = (x1, x2)
            
    return best_vertex, best_val


# Chạy thử nghiệm với test case mẫu
if __name__ == "__main__":
    # Các đỉnh giao điểm của miền đa diện lồi xác định bởi hệ ràng buộc:
    # 2*x1 + x2 <= 100 (Giờ GPU)
    # x1 + x2 <= 80    (Bộ nhớ VRAM)
    # x1 >= 0, x2 >= 0
    # Các đỉnh: A(0, 0), B(0, 80), C(20, 60), D(50, 0)
    vertices = [(0, 0), (0, 80), (20, 60), (50, 0)]
    c1, c2 = 40, 30  # Lợi nhuận: max f = 40*x1 + 30*x2

    optimal_point, max_profit = solve_lp_geometric(vertices, c1, c2)
    
    print(f"\nNghiệm tối ưu: {optimal_point}")
    print(f"Lợi nhuận tối đa: {max_profit} USD")
    
    # Kết quả kỳ vọng:
    # Nghiệm tối ưu: (20, 60)
    # Lợi nhuận tối đa: 2600 USD
