"""
LAB 1 - BÀI 5: Thuật toán Khử Gauss đưa Ma trận về Dạng Bậc thang (Gaussian Elimination)
Giải hệ A·x = b bằng biến đổi dòng sơ cấp trên ma trận bổ sung [A|b]:
  1. Partial Pivoting: chọn hàng có |phần tử| lớn nhất trong cột làm hàng chốt.
  2. Forward Elimination: triệt tiêu các phần tử bên dưới đường chéo về 0.
"""

EPS = 1e-12


def forward_elimination(aug_matrix):
    """Khử xuôi có chọn pivot, trả về ma trận bậc thang ở độ chính xác đầy đủ."""
    # Tạo bản sao (kiểu float) để không làm thay đổi ma trận đầu vào
    M = [[float(v) for v in row] for row in aug_matrix]
    m = len(M)        # số hàng
    n = len(M[0])     # số cột (cột cuối cùng là vector b)

    pivot_row = 0
    for k in range(n - 1):            # chỉ duyệt các cột hệ số, bỏ qua cột b
        if pivot_row >= m:
            break

        # 1. PARTIAL PIVOTING: tìm hàng i >= pivot_row có |M[i][k]| lớn nhất
        max_row = pivot_row
        for i in range(pivot_row + 1, m):
            if abs(M[i][k]) > abs(M[max_row][k]):
                max_row = i

        # Cột k không còn phần tử khác 0 -> không có pivot, chuyển sang cột kế
        if abs(M[max_row][k]) < EPS:
            continue

        # Hoán đổi hàng max_row với hàng pivot_row
        if max_row != pivot_row:
            M[pivot_row], M[max_row] = M[max_row], M[pivot_row]

        # 2. FORWARD ELIMINATION: khử các hàng bên dưới hàng chốt
        for i in range(pivot_row + 1, m):
            factor = M[i][k] / M[pivot_row][k]
            for j in range(k, n):
                M[i][j] -= factor * M[pivot_row][j]
            M[i][k] = 0.0             # gán đúng 0, tránh sai số dạng 1e-17

        pivot_row += 1

    return M


def gaussian_elimination(aug_matrix):
    """Trả về ma trận bổ sung ở dạng bậc thang (Row Echelon Form), làm tròn 2 chữ số."""
    M = forward_elimination(aug_matrix)
    # + 0.0 để chuyển -0.0 thành 0.0 khi in
    return [[round(v, 2) + 0.0 for v in row] for row in M]


def back_substitution(ref):
    """(Mở rộng) Thế ngược trên ma trận bậc thang n x (n+1) để tìm nghiệm x."""
    n = len(ref)
    x = [0.0] * n
    for i in range(n - 1, -1, -1):
        if abs(ref[i][i]) < EPS:
            print("Hệ suy biến: không có nghiệm duy nhất.")
            return None
        s = ref[i][n]
        for j in range(i + 1, n):
            s -= ref[i][j] * x[j]
        x[i] = s / ref[i][i]
    return x


# ===================================================================================
# PHÂN TÍCH ĐỘ PHỨC TẠP THỜI GIAN (ma trận vuông n x n, ma trận bổ sung n x (n+1)):
# - Với mỗi cột k = 0..n-1:
#     + Tìm pivot: duyệt (n - k) hàng                           -> O(n - k)
#     + Hoán đổi 2 hàng (Python chỉ đổi tham chiếu)             -> O(1)
#     + Khử xuôi: (n - k - 1) hàng, mỗi hàng (n - k + 1) phần tử -> O((n - k)^2)
# - Tổng số phép nhân/trừ: sum_{k=0}^{n-1} (n - k)^2 = n(n+1)(2n+1)/6 ≈ n^3 / 3
#   => Khử xuôi (Forward Elimination): O(n^3)
# - Thế ngược (Back Substitution): sum (n - i) ≈ n^2 / 2       => O(n^2)
# => Độ phức tạp toàn thuật toán khử Gauss: O(n^3). Bộ nhớ: O(n^2).
# Nhận xét: vì O(n^3), với n rất lớn (hàng chục nghìn đặc trưng) người ta dùng
# phương pháp lặp (Gradient Descent, Conjugate Gradient) thay cho giải trực tiếp.
# ===================================================================================


if __name__ == "__main__":
    # Hệ phương trình:
    #  2x +  y -  z =   8
    # -3x -  y + 2z = -11
    # -2x +  y + 2z =  -3
    augmented_matrix = [
        [2.0, 1.0, -1.0, 8.0],
        [-3.0, -1.0, 2.0, -11.0],
        [-2.0, 1.0, 2.0, -3.0]
    ]

    ref = gaussian_elimination(augmented_matrix)
    print("Ma trận bổ sung [A|b] ở dạng bậc thang (REF):")
    for row in ref:
        print(row)

    # Thế ngược trên ma trận chưa làm tròn để có nghiệm chính xác
    x = back_substitution(forward_elimination(augmented_matrix))
    x = [round(v, 6) + 0.0 for v in x]
    print(f"\nNghiệm của hệ: x = {x[0]}, y = {x[1]}, z = {x[2]}")  # x = 2, y = 3, z = -1

    # Kiểm tra lại: thay nghiệm vào hệ ban đầu
    print("Kiểm tra A·x so với b:")
    for row in augmented_matrix:
        lhs = sum(row[j] * x[j] for j in range(3))
        print(f"  {round(lhs, 6)} == {row[3]}")
