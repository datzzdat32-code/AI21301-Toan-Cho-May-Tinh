"""
LAB 1 - BÀI 1: Khởi tạo và Chuyển vị Ma trận (Transpose Matrix)
Ma trận A (m x n) -> Ma trận chuyển vị A^T (n x m), với A^T[j][i] = A[i][j].
"""


def transpose_matrix(A):
    """Trả về ma trận chuyển vị A^T bằng vòng lặp Python thuần."""
    if not A or not A[0]:
        return []

    # Bước 1: Xác định số hàng và số cột của ma trận gốc
    rows = len(A)
    cols = len(A[0])

    # Bước 2: Khởi tạo ma trận chuyển vị kích thước (cols x rows), toàn số 0
    A_T = [[0 for _ in range(rows)] for _ in range(cols)]

    # Bước 3 + 4: Duyệt từng phần tử và hoán đổi chỉ số hàng - cột
    for i in range(rows):
        for j in range(cols):
            A_T[j][i] = A[i][j]

    # Bước 5: Trả về kết quả
    return A_T


def print_matrix(M):
    for row in M:
        print(row)


if __name__ == "__main__":
    A = [
        [1, 2, 3],
        [4, 5, 6]
    ]

    print(f"Ma trận gốc A ({len(A)} x {len(A[0])}):")
    print_matrix(A)

    A_T = transpose_matrix(A)
    print(f"\nMa trận chuyển vị A_T ({len(A_T)} x {len(A_T[0])}):")
    print_matrix(A_T)
    # Kết quả kỳ vọng:
    # [1, 4]
    # [2, 5]
    # [3, 6]

    # Kiểm chứng tính chất (A^T)^T = A
    print("\nKiểm tra (A^T)^T == A:", transpose_matrix(A_T) == A)
