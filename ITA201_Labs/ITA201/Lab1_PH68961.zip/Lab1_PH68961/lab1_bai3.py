"""
LAB 1 - BÀI 3: Tích Ma trận và Vector (y = W · x)
Đầu ra của một tầng ẩn trong mạng nơ-ron truyền thẳng: y_i = <hàng i của W, x>.
"""


def matrix_vector_multiply(W, x):
    """
    W: ma trận m x n, x: vector n phần tử -> trả về vector y gồm m phần tử.
    Trả về None nếu kích thước không hợp lệ.
    """
    m = len(W)
    if m == 0:
        print("Lỗi: Ma trận W rỗng.")
        return None

    n = len(W[0])

    # Ràng buộc: số cột của W phải bằng số phần tử của x
    if n != len(x):
        print(f"Lỗi kích thước: W có {n} cột nhưng x có {len(x)} phần tử.")
        return None

    # Kiểm tra mọi hàng của W có cùng số cột
    for i in range(m):
        if len(W[i]) != n:
            print(f"Lỗi: hàng {i} của W có {len(W[i])} phần tử, khác {n}.")
            return None

    y = []
    for i in range(m):
        dot = 0                      # tích vô hướng hàng i của W với x
        for j in range(n):
            dot += W[i][j] * x[j]
        y.append(dot)
    return y


if __name__ == "__main__":
    W = [
        [0.2, 0.5, -0.1],
        [0.8, -0.3, 0.4]
    ]
    x = [10, 2, 5]

    y = matrix_vector_multiply(W, x)
    # Làm tròn khi in để loại bỏ sai số dấu phẩy động (vd: 9.399999999999999)
    print("y = W · x =", [round(v, 6) for v in y])  # Kết quả kỳ vọng: [2.5, 9.4]

    # Test trường hợp không hợp lệ
    print("\nTest kích thước sai (x có 2 phần tử):")
    print("Kết quả:", matrix_vector_multiply(W, [1, 2]))
