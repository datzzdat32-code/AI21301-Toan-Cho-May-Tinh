"""
LAB 1 - BÀI 2: Tính Chuẩn Vector L1 và L2 (Vector Norms)
Ứng dụng: đo độ lớn của vector sai số e = y - y_hat trong hàm mất mát
  - Chuẩn L1 (Manhattan)  <-> MAE (Mean Absolute Error)
  - Chuẩn L2 (Euclidean)  <-> MSE / RMSE
"""


def norm_l1(v):
    """Chuẩn Manhattan: ||v||_1 = sum(|v_i|)."""
    total = 0
    for x in v:
        total += abs(x)
    return total


def norm_l2(v):
    """Chuẩn Euclidean: ||v||_2 = sqrt(sum(v_i^2))."""
    sum_sq = 0
    for x in v:
        sum_sq += x ** 2
    return sum_sq ** 0.5


def error_vector(y, y_hat):
    """Tính vector sai số e = y - y_hat."""
    if len(y) != len(y_hat):
        print("Lỗi: y và y_hat phải có cùng số phần tử.")
        return None
    return [y[i] - y_hat[i] for i in range(len(y))]


if __name__ == "__main__":
    # Test case trong đề
    error_vec = [3, -4]
    print(f"Vector sai số e = {error_vec}")
    print(f"L1 Norm: {norm_l1(error_vec)}")  # Kết quả: 7
    print(f"L2 Norm: {norm_l2(error_vec)}")  # Kết quả: 5.0

    # Ví dụ ứng dụng trong học máy: so sánh dự đoán với giá trị thực tế
    y = [3.0, 5.0, 2.5, 7.0]
    y_hat = [2.5, 5.0, 4.0, 8.0]
    e = error_vector(y, y_hat)
    n = len(e)
    print(f"\ny     = {y}")
    print(f"y_hat = {y_hat}")
    print(f"e     = {e}")
    print(f"||e||_1 = {norm_l1(e)}    -> MAE  = ||e||_1 / n       = {norm_l1(e) / n}")
    print(f"||e||_2 = {norm_l2(e):.4f} -> RMSE = ||e||_2 / sqrt(n) = {norm_l2(e) / n ** 0.5:.4f}")
