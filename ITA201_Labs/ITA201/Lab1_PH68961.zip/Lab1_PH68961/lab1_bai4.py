"""
LAB 1 - BÀI 4: Nhân hai Ma trận (C = A x B)
A (m x n) · B (n x p) = C (m x p), với C[i][j] = sum_k A[i][k] * B[k][j].
"""


def matrix_multiply(A, B):
    """Nhân hai ma trận bằng 3 vòng lặp lồng nhau, in ra số phép nhân đã thực hiện."""
    if not A or not B:
        print("Lỗi: Ma trận rỗng.")
        return None

    m = len(A)
    n = len(A[0])

    # Kiểm tra điều kiện: số cột của A phải bằng số hàng của B
    if n != len(B):
        print(f"Lỗi kích thước: A có {n} cột nhưng B có {len(B)} hàng.")
        return None

    p = len(B[0])

    # Khởi tạo ma trận kết quả C (m x p)
    C = [[0 for _ in range(p)] for _ in range(m)]
    mult_count = 0

    for i in range(m):              # duyệt hàng của A
        for j in range(p):          # duyệt cột của B
            for k in range(n):      # tích vô hướng hàng i (A) và cột j (B)
                C[i][j] += A[i][k] * B[k][j]
                mult_count += 1

    print(f"Tổng số phép nhân số học đã thực hiện: {mult_count} "
          f"(= m * n * p = {m} * {n} * {p})")
    return C


if __name__ == "__main__":
    A = [
        [1, 2, 3],
        [4, 5, 6]
    ]  # 2 x 3
    B = [
        [7, 8],
        [9, 1],
        [2, 3]
    ]  # 3 x 2

    C = matrix_multiply(A, B)
    print("Ma trận C = A x B (2 x 2):")
    for row in C:
        print(row)
    # Kết quả kỳ vọng:
    # [31, 19]
    # [85, 55]

    print("\nTest kích thước không khớp (A x A):")
    print("Kết quả:", matrix_multiply(A, A))
