"""
LAB 2 - BÀI 2: Kiểm tra Độc lập tuyến tính trong không gian 2D
Hai vector v1, v2 phụ thuộc tuyến tính (cùng phương) <=> det([v1; v2]) = x1*y2 - x2*y1 = 0.
Ứng dụng: nếu 2 thuộc tính phụ thuộc tuyến tính thì có thể loại bỏ 1 thuộc tính (dư thừa).
"""


def is_linearly_dependent_2d(v1, v2, eps=1e-9):
    """Trả về True nếu v1, v2 phụ thuộc tuyến tính, False nếu độc lập tuyến tính."""
    det = v1[0] * v2[1] - v1[1] * v2[0]
    if abs(det) < eps:   # dùng ngưỡng eps vì sai số số thực
        return True
    return False


if __name__ == "__main__":
    print(is_linearly_dependent_2d([2, 4], [4, 8]))  # True  (v2 = 2 * v1)
    print(is_linearly_dependent_2d([2, 4], [1, 5]))  # False

    # Các test bổ sung
    tests = [
        ([1, 0], [0, 1]),        # cơ sở chuẩn -> độc lập
        ([0, 0], [3, 7]),        # có vector 0 -> luôn phụ thuộc
        ([1.5, -3], [-0.5, 1]),  # v1 = -3 * v2 -> phụ thuộc
        ([0.1, 0.2], [0.3, 0.6]) # phụ thuộc, kiểm tra sai số số thực
    ]
    print("\nTest bổ sung:")
    for a, b in tests:
        dep = is_linearly_dependent_2d(a, b)
        print(f"  {a} và {b}: {'Phụ thuộc' if dep else 'Độc lập'} tuyến tính")
