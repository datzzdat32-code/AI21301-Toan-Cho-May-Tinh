"""
LAB 2 - BÀI 3: Tìm Hạt nhân Ker(f) và Số chiều Nullity qua Hệ thuần nhất A·x = 0
f: R^3 -> R^2 biểu diễn bởi ma trận A (2 x 3).
Ker(f) = { x thuộc R^3 | A·x = 0 }.
"""

EPS = 1e-10


def rref(A):
    """
    Đưa ma trận A về dạng bậc thang rút gọn (RREF) bằng biến đổi dòng sơ cấp.
    Trả về (ma trận RREF, danh sách chỉ số các cột pivot).
    """
    M = [[float(v) for v in row] for row in A]
    rows, cols = len(M), len(M[0])
    pivot_cols = []
    r = 0
    for c in range(cols):
        if r >= rows:
            break
        # Chọn hàng có |phần tử| lớn nhất ở cột c (partial pivoting)
        p = r
        for i in range(r + 1, rows):
            if abs(M[i][c]) > abs(M[p][c]):
                p = i
        if abs(M[p][c]) < EPS:
            continue                      # cột c không có pivot -> biến tự do
        M[r], M[p] = M[p], M[r]           # hoán đổi dòng
        pv = M[r][c]
        M[r] = [v / pv for v in M[r]]     # chuẩn hóa pivot về 1
        for i in range(rows):             # khử cả phía trên và phía dưới pivot
            if i != r:
                f = M[i][c]
                M[i] = [M[i][j] - f * M[r][j] for j in range(cols)]
        pivot_cols.append(c)
        r += 1
    # Làm sạch sai số số thực
    M = [[0.0 if abs(v) < EPS else v for v in row] for row in M]
    return M, pivot_cols


def find_kernel_basis_2x3(A):
    """
    Trả về (danh sách vector cơ sở của Ker(f), dim(Ker) = nullity).
    Trường hợp hạng 2: RREF(A) = [[1, 0, c1], [0, 1, c2]]
      -> đặt x3 = 1.0  =>  x1 = -c1, x2 = -c2  =>  Ker(f) = span{[-c1, -c2, 1]}.
    Hàm xử lý tổng quát cho cả trường hợp hạng 1 hoặc 0.
    """
    n = len(A[0])                                  # số ẩn = 3
    R, pivots = rref(A)
    free_vars = [j for j in range(n) if j not in pivots]

    basis = []
    for fv in free_vars:
        x = [0.0] * n
        x[fv] = 1.0                                # đặt biến tự do = 1, các biến tự do khác = 0
        for row_idx, pc in enumerate(pivots):
            x[pc] = -R[row_idx][fv]                # biến pivot = -(hệ số của biến tự do)
        basis.append([round(v, 6) + 0.0 for v in x])

    nullity = len(free_vars)
    return basis, nullity


def mat_vec(A, x):
    return [sum(A[i][j] * x[j] for j in range(len(x))) for i in range(len(A))]


def run_test(A):
    R, pivots = rref(A)
    basis, nullity = find_kernel_basis_2x3(A)
    rank = len(pivots)
    print(f"A = {A}")
    print(f"RREF(A) = {[[round(v, 4) + 0.0 for v in row] for row in R]}")
    print(f"Cơ sở của Ker(f): {basis}")
    print(f"dim(Ker) = nullity = {nullity},  rank(A) = {rank}")
    print(f"Định lý hạng - số chiều: rank + nullity = {rank} + {nullity} = {rank + nullity} (= số chiều R^3)")
    for v in basis:
        print(f"  Kiểm tra A·{v} = {[round(t, 4) + 0.0 for t in mat_vec(A, v)]}")
    print()


if __name__ == "__main__":
    # Test 1: hạng 2 -> RREF dạng [[1, 0, c1], [0, 1, c2]], Ker có 1 chiều
    run_test([[1, 2, 3],
              [4, 5, 6]])

    # Test 2: hạng 2 với hệ số thực
    run_test([[2, -1, 1],
              [1, 3, -2]])

    # Test 3: hạng 1 (2 hàng tỉ lệ) -> Ker có 2 chiều
    run_test([[1, 2, 3],
              [2, 4, 6]])
