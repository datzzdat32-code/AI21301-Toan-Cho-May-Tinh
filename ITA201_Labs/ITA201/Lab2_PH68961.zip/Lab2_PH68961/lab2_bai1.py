"""
LAB 2 - BÀI 1: Tổ hợp Tuyến tính và Tọa độ theo Cơ sở mới
v = c1*b1 + c2*b2 + ... + ck*bk   (c là tọa độ của v trong cơ sở B)
"""


def compute_linear_combination(B, c):
    """Tính v = sum(c[i] * B[i]) với B[i] là vector cơ sở thứ i."""
    if len(B) != len(c):
        print("Lỗi: số vector cơ sở phải bằng số hệ số.")
        return None

    # Bước 1: Số chiều của không gian
    dim = len(B[0])
    # Bước 2: Khởi tạo vector kết quả toàn 0
    v = [0.0] * dim
    # Bước 3 + 4: Cộng dồn c[i] * B[i][j] vào v[j]
    for i in range(len(B)):
        for j in range(dim):
            v[j] += c[i] * B[i][j]
    # Bước 5: Trả về kết quả
    return v


def find_coordinates_2d(B, v):
    """
    (Mở rộng - Change of Basis) Bài toán ngược: cho v trong cơ sở chuẩn,
    tìm tọa độ c = [c1, c2] của v theo cơ sở B = {b1, b2}.
    Giải hệ c1*b1 + c2*b2 = v bằng quy tắc Cramer.
    """
    b1, b2 = B
    det = b1[0] * b2[1] - b2[0] * b1[1]
    if abs(det) < 1e-9:
        print("Lỗi: b1, b2 phụ thuộc tuyến tính -> không phải là một cơ sở.")
        return None
    c1 = (v[0] * b2[1] - b2[0] * v[1]) / det
    c2 = (b1[0] * v[1] - v[0] * b1[1]) / det
    return [c1, c2]


if __name__ == "__main__":
    B = [
        [1, 0],  # b1
        [1, 1]   # b2
    ]
    c = [-2, 7]

    v = compute_linear_combination(B, c)
    print(f"Vector kết quả v = {c[0]}*b1 + {c[1]}*b2 = {v}")  # [5.0, 7.0]

    # Kiểm chứng chiều ngược lại: từ v tìm lại tọa độ theo cơ sở B
    coords = find_coordinates_2d(B, v)
    print(f"Tọa độ của v theo cơ sở B: {coords}")            # [-2.0, 7.0]

    # Thêm một ví dụ khác
    v2 = [3, 5]
    c2 = find_coordinates_2d(B, v2)
    print(f"\nv2 = {v2} có tọa độ theo B là {c2}")
    print(f"Kiểm tra lại: {compute_linear_combination(B, c2)}")
