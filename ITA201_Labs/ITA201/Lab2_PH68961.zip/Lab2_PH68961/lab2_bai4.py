"""
LAB 2 - BÀI 4: Phép biến đổi Hình học (Co giãn và Xoay) trên tập điểm 2D
  Co giãn: S = [[sx, 0], [0, sy]]
  Xoay   : R = [[cos(rad), -sin(rad)], [sin(rad), cos(rad)]]  (ngược chiều kim đồng hồ)
"""
import math


def apply_linear_map(M, points):
    """Áp dụng ánh xạ tuyến tính 2x2 lên từng điểm [x, y], làm tròn 2 chữ số."""
    result = []
    for x, y in points:
        new_x = M[0][0] * x + M[0][1] * y
        new_y = M[1][0] * x + M[1][1] * y
        # + 0.0 để tránh in ra -0.0
        result.append([round(new_x, 2) + 0.0, round(new_y, 2) + 0.0])
    return result


def scale_points(points, sx, sy):
    """Co giãn tập điểm theo hệ số sx (trục x) và sy (trục y)."""
    S = [[sx, 0],
         [0, sy]]
    return apply_linear_map(S, points)


def rotate_points(points, angle_degrees):
    """Xoay tập điểm quanh gốc tọa độ một góc angle_degrees (độ)."""
    rad = math.radians(angle_degrees)
    R = [[math.cos(rad), -math.sin(rad)],
         [math.sin(rad), math.cos(rad)]]
    return apply_linear_map(R, points)


if __name__ == "__main__":
    # Hình chữ nhật 2 x 1 có một đỉnh tại gốc tọa độ
    points = [[0, 0], [2, 0], [2, 1], [0, 1]]
    print("Tập điểm gốc       :", points)

    print("Co giãn (sx=2, sy=3):", scale_points(points, 2, 3))
    print("Xoay 90 độ          :", rotate_points(points, 90))
    print("Xoay 45 độ          :", rotate_points(points, 45))
    print("Xoay 180 độ         :", rotate_points(points, 180))

    # Kiểm chứng: xoay 360 độ quay về vị trí ban đầu
    print("Xoay 360 độ         :", rotate_points(points, 360))

    # Kiểm chứng: phép xoay bảo toàn độ dài vector
    p = [3, 4]
    q = rotate_points([p], 37)[0]
    print(f"\n|{p}| = {math.hypot(*p):.2f},  sau khi xoay 37 độ: {q} có độ dài {math.hypot(*q):.2f}")
