"""
LAB 2 - BÀI 5: Pipeline Tăng cường Dữ liệu Ảnh (Data Augmentation) với Tọa độ Đồng nhất
Chuỗi biến đổi Affine: Co giãn (S) -> Xoay (R) -> Tịnh tiến (T) trên Bounding Box.
Vì S được áp dụng trước, ma trận tổng hợp là M = T · R · S (nhân từ phải sang trái).
"""
import math


def mat_mul_3x3(A, B):
    """Nhân hai ma trận 3x3."""
    C = [[0.0] * 3 for _ in range(3)]
    for i in range(3):
        for j in range(3):
            for k in range(3):
                C[i][j] += A[i][k] * B[k][j]
    return C


def create_affine_matrix(sx, sy, angle_deg, tx, ty):
    """Tạo ma trận biến đổi Affine 3x3: M = T · R · S."""
    rad = math.radians(angle_deg)
    c, s = math.cos(rad), math.sin(rad)

    S = [[sx, 0, 0],
         [0, sy, 0],
         [0, 0, 1]]
    R = [[c, -s, 0],
         [s, c, 0],
         [0, 0, 1]]
    T = [[1, 0, tx],
         [0, 1, ty],
         [0, 0, 1]]
    return mat_mul_3x3(T, mat_mul_3x3(R, S))


def transform_bounding_box(bbox, affine_matrix):
    """
    bbox: danh sách các đỉnh [x, y].
    Chuyển mỗi đỉnh sang tọa độ đồng nhất [x, y, 1], nhân với ma trận 3x3,
    rồi chuyển về tọa độ 2D (chia cho thành phần w; với ma trận affine thì w = 1).
    """
    new_bbox = []
    for x, y in bbox:
        p = [x, y, 1.0]
        q = [sum(affine_matrix[i][j] * p[j] for j in range(3)) for i in range(3)]
        new_bbox.append([round(q[0] / q[2], 2) + 0.0, round(q[1] / q[2], 2) + 0.0])
    return new_bbox


def axis_aligned_bbox(points):
    """(Mở rộng) Sau khi xoay, hộp không còn song song trục. Các framework (YOLO, COCO)
    cần hộp dạng [x_min, y_min, x_max, y_max] nên lấy hộp bao nhỏ nhất của 4 đỉnh."""
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    return [min(xs), min(ys), max(xs), max(ys)]


# =====================================================================================
# VÌ SAO TỌA ĐỘ ĐỒNG NHẤT 3x3 GIÚP GPU XỬ LÝ SONG SONG NHANH HƠN TRONG DEEP LEARNING?
# 1) Biến phép tịnh tiến thành phép nhân ma trận:
#    Ở tọa độ 2D thường, tịnh tiến p' = p + t là phép CỘNG, không biểu diễn được bằng
#    ma trận 2x2. Khi thêm thành phần 1 ([x, y] -> [x, y, 1]), tịnh tiến trở thành
#    phép NHÂN với ma trận 3x3. Co giãn, xoay, tịnh tiến, cắt (shear), lật... đều có
#    chung một dạng duy nhất: nhân ma trận.
# 2) Gộp cả chuỗi biến đổi thành MỘT ma trận:
#    M = T · R · S chỉ tính 1 lần (ma trận 3x3, rất rẻ), rồi áp lên mọi điểm. Thay vì
#    duyệt dữ liệu 3 lần (scale -> rotate -> translate), ta chỉ duyệt 1 lần, giảm số lần
#    đọc/ghi bộ nhớ (vốn là nút thắt chính trên GPU).
# 3) Xử lý theo lô (batch) = một phép GEMM duy nhất:
#    Xếp N điểm thành ma trận P (N x 3), kết quả P' = P · M^T chỉ là MỘT phép nhân ma
#    trận lớn. GPU có hàng nghìn lõi và Tensor Core, thư viện cuBLAS được tối ưu riêng cho
#    GEMM; mỗi điểm được tính độc lập nên song song hóa hoàn toàn (SIMT), không có rẽ nhánh
#    if/else cho từng loại biến đổi.
# 4) Dữ liệu có kích thước cố định, đồng nhất: có thể xếp nhiều ảnh thành tensor
#    (Batch x 3 x 3) và biến đổi đồng thời, ví dụ affine_grid / Spatial Transformer Network
#    trong PyTorch.
# =====================================================================================


if __name__ == "__main__":
    # Bounding box của một đối tượng: 4 đỉnh của hình chữ nhật [10, 20] -> [50, 60]
    bbox = [[10, 20], [50, 20], [50, 60], [10, 60]]
    sx, sy, angle, tx, ty = 1.5, 1.5, 30, 100, 50

    M = create_affine_matrix(sx, sy, angle, tx, ty)
    print(f"Ma trận Affine 3x3 (sx={sx}, sy={sy}, góc={angle}°, tx={tx}, ty={ty}):")
    for row in M:
        print([round(v, 4) + 0.0 for v in row])

    new_bbox = transform_bounding_box(bbox, M)
    print(f"\nBounding box gốc      : {bbox}")
    print(f"Bounding box sau biến đổi: {new_bbox}")
    print(f"Hộp bao song song trục [x_min, y_min, x_max, y_max]: {axis_aligned_bbox(new_bbox)}")

    # Kiểm chứng: áp dụng lần lượt từng phép phải cho cùng kết quả với ma trận gộp
    I_S = create_affine_matrix(sx, sy, 0, 0, 0)       # chỉ co giãn
    I_R = create_affine_matrix(1, 1, angle, 0, 0)     # chỉ xoay
    I_T = create_affine_matrix(1, 1, 0, tx, ty)       # chỉ tịnh tiến
    step = transform_bounding_box(bbox, I_S)
    step = transform_bounding_box(step, I_R)
    step = transform_bounding_box(step, I_T)
    print(f"\nÁp dụng lần lượt S -> R -> T: {step}")
    print("Trùng với ma trận gộp:",
          all(abs(a - b) < 0.02 for p, q in zip(step, new_bbox) for a, b in zip(p, q)))
