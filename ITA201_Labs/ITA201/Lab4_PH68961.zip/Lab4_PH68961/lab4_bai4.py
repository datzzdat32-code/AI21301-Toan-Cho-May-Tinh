"""
LAB 4 - BÀI 4: Bài toán Xếp N Quân hậu (N-Queens) bằng Quay lui + Cắt tỉa nhánh
Mỗi hàng đặt đúng 1 quân hậu. Dùng 3 tập hợp để kiểm tra an toàn O(1):
  cols  : các cột đã có hậu
  diag1 : đường chéo chính, đặc trưng bởi (r - c)
  diag2 : đường chéo phụ,   đặc trưng bởi (r + c)
"""


def solve_n_queens(n, print_boards=True, max_print=None):
    """Trả về tổng số cách xếp hợp lệ; in các bàn cờ tìm được (tối đa max_print bàn)."""
    solutions = []
    queens = [-1] * n                 # queens[r] = cột đặt hậu ở hàng r
    cols, diag1, diag2 = set(), set(), set()

    def backtrack(row):
        if row == n:                  # đã đặt đủ n quân hậu -> 1 nghiệm
            board = ["".join("Q" if queens[r] == c else "." for c in range(n))
                     for r in range(n)]
            solutions.append(board)
            return

        for c in range(n):
            # Cắt tỉa: bỏ qua ô bị tấn công theo cột hoặc đường chéo
            if c in cols or (row - c) in diag1 or (row + c) in diag2:
                continue

            # Chọn: đặt hậu tại (row, c)
            queens[row] = c
            cols.add(c)
            diag1.add(row - c)
            diag2.add(row + c)

            backtrack(row + 1)

            # Quay lui: gỡ hậu tại (row, c)
            queens[row] = -1
            cols.remove(c)
            diag1.remove(row - c)
            diag2.remove(row + c)

    backtrack(0)

    if print_boards:
        limit = len(solutions) if max_print is None else min(max_print, len(solutions))
        for idx in range(limit):
            print(f"Cách xếp {idx + 1}: {solutions[idx]}")
            for line in solutions[idx]:
                print("   ", " ".join(line))
            print()
        if limit < len(solutions):
            print(f"... (còn {len(solutions) - limit} cách xếp khác không in ra)\n")

    return len(solutions)


if __name__ == "__main__":
    print("========== n = 4 ==========")
    total4 = solve_n_queens(4)
    print(f"Tổng số cách xếp với n = 4: {total4}")   # 2

    print("\n========== n = 8 ==========")
    total8 = solve_n_queens(8, max_print=3)
    print(f"Tổng số cách xếp với n = 8: {total8}")   # 92
    # Ghi chú: đề bài ghi 924 là lỗi đánh máy; đáp án đúng của bài toán 8 quân hậu là 92.

    print("\nSố nghiệm với n = 1..10:")
    print([solve_n_queens(k, print_boards=False) for k in range(1, 11)])
    # [1, 0, 0, 2, 10, 4, 40, 92, 352, 724]
