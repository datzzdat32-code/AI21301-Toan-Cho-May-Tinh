"""
LAB 4 - BÀI 3: Thuật toán Sinh Hoán vị theo Thứ tự Từ điển (Lexicographical Permutations)
Sinh toàn bộ n! hoán vị của {1, 2, ..., n} bằng vòng lặp while (không dùng itertools).
"""


def generate_permutations(n):
    if n < 1:
        return []

    a = list(range(1, n + 1))        # cấu hình đầu tiên: [1, 2, ..., n]
    results = []

    while True:
        results.append(a[:])          # lưu bản sao cấu hình hiện tại

        # 1. Tìm vị trí i lớn nhất sao cho a[i] < a[i+1]
        i = n - 2
        while i >= 0 and a[i] > a[i + 1]:
            i -= 1

        # 2. Không tìm thấy -> cấu hình cuối cùng [n, n-1, ..., 1], dừng
        if i < 0:
            break

        # 3. Tìm vị trí k lớn nhất sao cho a[k] > a[i]
        k = n - 1
        while a[k] < a[i]:
            k -= 1

        # 4. Đổi chỗ a[i] và a[k]
        a[i], a[k] = a[k], a[i]

        # 5. Lật ngược đoạn a[i+1 .. n-1]
        left, right = i + 1, n - 1
        while left < right:
            a[left], a[right] = a[right], a[left]
            left += 1
            right -= 1

    return results


if __name__ == "__main__":
    perms = generate_permutations(3)
    print(f"n = 3: sinh được {len(perms)} hoán vị (3! = 6)")
    for p in perms:
        print(p)
    # Kết quả kỳ vọng: [1,2,3], [1,3,2], [2,1,3], [2,3,1], [3,1,2], [3,2,1]

    # Kiểm tra với n = 4, 5
    for n in [4, 5]:
        ps = generate_permutations(n)
        fact = 1
        for t in range(2, n + 1):
            fact *= t
        print(f"\nn = {n}: sinh được {len(ps)} hoán vị ({n}! = {fact})")
        print("  Đúng thứ tự từ điển:", ps == sorted(ps))
        print("  Không trùng lặp    :", len(set(map(tuple, ps))) == len(ps))
