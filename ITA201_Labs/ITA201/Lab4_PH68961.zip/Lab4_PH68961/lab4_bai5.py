"""
LAB 4 - BÀI 5: Pipeline Tối ưu Siêu tham số (Grid Search) & Phân tích Đụng độ theo Nguyên lý Dirichlet
"""
import hashlib


# ------------------------- 1. Grid Search bằng Quay lui -------------------------
def custom_grid_search(param_grid):
    """
    Sinh toàn bộ cấu hình (dict) từ param_grid bằng quay lui.
    Mỗi tầng đệ quy ứng với 1 siêu tham số -> hoạt động với số tham số bất kỳ,
    không cần viết cứng các vòng for lồng nhau.
    """
    keys = list(param_grid.keys())
    configs = []

    def backtrack(depth, current):
        if depth == len(keys):              # đã chọn giá trị cho mọi tham số
            configs.append(dict(current))   # lưu bản sao
            return
        key = keys[depth]
        for value in param_grid[key]:
            current[key] = value            # chọn
            backtrack(depth + 1, current)   # đệ quy tham số tiếp theo
            del current[key]                # quay lui

    backtrack(0, {})
    return configs


# ---------------------------- 2. Nguyên lý Nhân ----------------------------
def count_configurations(param_grid):
    """|Configurations| = |V1| x |V2| x ... x |Vk| (nguyên lý nhân)."""
    total = 1
    for values in param_grid.values():
        total *= len(values)
    return total


# ------------------------ 3. Nguyên lý Dirichlet mở rộng ------------------------
def dirichlet_min_collision(N, k):
    """
    Đặt N đối tượng vào k hộp thì tồn tại ít nhất 1 hộp chứa >= ceil(N / k) đối tượng.
    Dùng phép chia nguyên để tránh sai số số thực: ceil(N / k) = (N + k - 1) // k.
    """
    return (N + k - 1) // k


def bucket_of(key, k):
    """Băm ổn định (MD5) một chuỗi vào 1 trong k cụm máy chủ."""
    return int(hashlib.md5(key.encode()).hexdigest(), 16) % k


def mock_evaluate(config):
    """(Mô phỏng) Hàm chấm điểm giả lập thay cho việc huấn luyện mô hình thật."""
    lr_score = {0.001: 0.80, 0.01: 0.88, 0.1: 0.75}[config['learning_rate']]
    bs_score = {16: 0.02, 32: 0.03, 64: 0.01}[config['batch_size']]
    opt_score = {'Adam': 0.04, 'SGD': 0.0}[config['optimizer']]
    return round(lr_score + bs_score + opt_score, 4)


if __name__ == "__main__":
    param_grid = {
        'learning_rate': [0.001, 0.01, 0.1],
        'batch_size': [16, 32, 64],
        'optimizer': ['Adam', 'SGD']
    }

    # 1. Sinh toàn bộ cấu hình
    configs = custom_grid_search(param_grid)
    print(f"Số cấu hình sinh bằng quay lui: {len(configs)}")
    for i, cfg in enumerate(configs, 1):
        print(f"  {i:2d}. {cfg}")

    # 2. Nguyên lý nhân
    sizes = " * ".join(str(len(v)) for v in param_grid.values())
    total = count_configurations(param_grid)
    print(f"\nNguyên lý nhân: |Configurations| = {sizes} = {total}")
    print("Khớp với số cấu hình sinh ra:", total == len(configs))

    # Thử với một param_grid bất kỳ khác
    other_grid = {'max_depth': [3, 5, 7, 9], 'n_estimators': [100, 200], 'criterion': ['gini', 'entropy'],
                  'min_samples_leaf': [1, 2, 4]}
    print(f"Grid khác {list(other_grid)}: {count_configurations(other_grid)} cấu hình "
          f"(sinh thực tế: {len(custom_grid_search(other_grid))})")

    # (Mô phỏng) Chọn cấu hình tốt nhất
    best = max(configs, key=mock_evaluate)
    print(f"\n[Mô phỏng] Cấu hình tốt nhất: {best} - điểm {mock_evaluate(best)}")

    # 3. Nguyên lý Dirichlet
    N, k = 105, 10
    m = dirichlet_min_collision(N, k)
    print(f"\nDirichlet mở rộng: {N} mô hình vào {k} cụm máy chủ")
    print(f"=> Chắc chắn có ít nhất 1 cụm chứa >= ceil({N}/{k}) = {m} mô hình")

    # Kiểm chứng bằng mô phỏng phân bố băm thực tế
    buckets = [0] * k
    for i in range(N):
        buckets[bucket_of(f"model_{i:03d}", k)] += 1
    print(f"Mô phỏng băm MD5 -> số mô hình mỗi cụm: {buckets}")
    print(f"Cụm đông nhất: {max(buckets)} mô hình (>= {m}, đúng như Dirichlet)")

    # Áp dụng cho chính 18 cấu hình Grid Search
    print(f"Với {total} cấu hình vào {k} cụm: ít nhất 1 cụm chứa >= "
          f"{dirichlet_min_collision(total, k)} cấu hình")

# =====================================================================================
# Ý NGHĨA CỦA NGUYÊN LÝ DIRICHLET TRONG CÂN BẰNG TẢI HỆ THỐNG AI
# - Với 105 mô hình và 10 cụm, trung bình là 10.5 mô hình/cụm. Dirichlet khẳng định KHÔNG
#   THỂ chia đều tuyệt đối: dù hàm băm tốt đến đâu, luôn có ít nhất 1 cụm chứa >= 11 mô hình.
#   Đây là CẬN DƯỚI của tải lớn nhất: phân bố lý tưởng nhất là 5 cụm x 11 + 5 cụm x 10.
# - Lập kế hoạch tài nguyên: mỗi cụm phải được cấp dung lượng (bộ nhớ, GPU, băng thông) đủ
#   cho tối thiểu 11 mô hình, nếu chỉ cấp cho 10 thì chắc chắn có cụm bị quá tải.
# - Đánh giá chất lượng hàm băm: nếu cụm đông nhất lớn hơn nhiều so với 11 (như kết quả mô
#   phỏng ở trên), hàm băm đang phân bố lệch -> cần cân bằng lại, ví dụ: Consistent Hashing
#   với virtual nodes, round-robin, hoặc tăng số cụm k.
# - Đụng độ (collision) là tất yếu khi N > k: hệ thống lưu trữ phải luôn có cơ chế xử lý
#   nhiều khóa trong cùng một bucket (danh sách/chaining, khóa tổ hợp...).
# =====================================================================================
