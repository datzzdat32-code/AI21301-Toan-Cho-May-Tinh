"""
LAB 4 - BÀI 1: Thuật toán Sinh Chuỗi Nhị phân Độ dài N (Binary Strings Generation)
Bit 1 = giữ lại đặc trưng, bit 0 = loại bỏ đặc trưng. Sinh 2^n cấu hình theo thứ tự từ điển,
KHÔNG dùng đệ quy.
"""


def generate_binary_strings(n):
    results = []
    a = [0] * n                      # Bước 1: cấu hình đầu tiên 000...0

    while True:                      # Bước 2
        # Bước 3: lưu cấu hình hiện tại
        results.append("".join(str(bit) for bit in a))

        # Bước 4: tìm bit 0 đầu tiên từ phải sang trái,
        #         đồng thời đặt các bit 1 phía sau nó về 0
        i = n - 1
        while i >= 0 and a[i] == 1:
            a[i] = 0
            i -= 1

        # Bước 5: không còn bit 0 -> đã đến cấu hình cuối 111...1
        if i < 0:
            break

        # Bước 6: đổi bit 0 thành 1
        a[i] = 1

    return results


if __name__ == "__main__":
    binary_list = generate_binary_strings(3)
    print(f"Tổng số chuỗi nhị phân sinh được (2^3 = 8): {len(binary_list)}")
    print("Danh sách chuỗi:", binary_list)
    # Kết quả kỳ vọng: ['000', '001', '010', '011', '100', '101', '110', '111']

    # Ứng dụng: ánh xạ mỗi chuỗi nhị phân thành một tập đặc trưng
    features = ["Age", "Income", "Score"]
    print("\nÁnh xạ chuỗi nhị phân -> tập đặc trưng được chọn:")
    for s in binary_list:
        chosen = [features[i] for i in range(len(s)) if s[i] == "1"]
        print(f"  {s} -> {chosen}")

    # Kiểm tra với n = 4
    print(f"\nn = 4: sinh được {len(generate_binary_strings(4))} chuỗi (2^4 = 16)")
