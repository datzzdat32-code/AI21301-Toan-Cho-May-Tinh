"""
LAB 4 - BÀI 2: Thuật toán Quay lui Sinh tất cả Tập con Đặc trưng (Feature Subsets via Backtracking)
Mỗi nút của cây đệ quy là một tập con -> tổng cộng 2^n tập con (kể cả tập rỗng).
"""


def generate_subsets_backtracking(features):
    all_subsets = []

    def backtrack(start_index, current_path):
        # Bước 2: lưu bản sao của tập con hiện tại
        all_subsets.append(list(current_path))

        # Bước 3: duyệt các đặc trưng phía sau start_index
        for i in range(start_index, len(features)):
            current_path.append(features[i])   # Bước 4: chọn
            backtrack(i + 1, current_path)     # Bước 5: đệ quy
            current_path.pop()                 # Bước 6: quay lui (undo)

    backtrack(0, [])
    return all_subsets


if __name__ == "__main__":
    features = ['Age', 'Income', 'Score']
    subsets = generate_subsets_backtracking(features)
    print(f"Tổng số tập con sinh được (2^3 = 8): {len(subsets)}")
    for s in subsets:
        print(s)

    # Kiểm tra: số tập con có k phần tử = C(n, k)
    print("\nPhân bố theo kích thước tập con:")
    for k in range(len(features) + 1):
        cnt = sum(1 for s in subsets if len(s) == k)
        print(f"  |S| = {k}: {cnt} tập con")
