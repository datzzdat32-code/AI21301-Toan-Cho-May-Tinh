"""
LAB 7 - BÀI 1: Mô phỏng Chuyển dịch Trạng thái Chuỗi Markov & Tìm Trạng thái Dừng
Môn học: AI21301 - Toán cho học máy
"""

def simulate_markov_chain(P, pi_0, num_steps=50):
    """
    Mô phỏng chuỗi Markov và tính phân phối xác suất trạng thái sau num_steps bước.
    Tìm trạng thái dừng pi* thỏa mãn pi* = pi* * P.
    
    Parameters:
        P (list of list): Ma trận xác suất chuyển đổi kích thước n x n (tổng mỗi hàng bằng 1).
        pi_0 (list): Vector phân phối xác suất ban đầu (kích thước n).
        num_steps (int): Số bước chuyển dịch thời gian (mặc định 50).
        
    Returns:
        list: Vector xác suất trạng thái dừng pi*, làm tròn 4 chữ số thập phân.
    """
    n = len(pi_0)
    pi = list(pi_0)
    
    for _ in range(num_steps):
        # Tính pi_next = pi * P
        # Với mỗi trạng thái j: pi_next[j] = sum(pi[i] * P[i][j] for i in range(n))
        pi_next = [0.0] * n
        for j in range(n):
            pi_next[j] = sum(pi[i] * P[i][j] for i in range(n))
            
        # Kiểm tra hội tụ sớm nếu hiệu số < 1e-6
        converged = all(abs(pi_next[j] - pi[j]) < 1e-6 for j in range(n))
        pi = pi_next
        if converged:
            break
            
    return [round(val, 4) for val in pi]


# Chạy thử nghiệm với test case mẫu
if __name__ == "__main__":
    # Mô hình dự báo thời tiết: S = ['Nắng', 'Mưa']
    P = [
        [0.8, 0.2],  # Nếu hôm nay Nắng: 80% mai Nắng, 20% mai Mưa
        [0.4, 0.6]   # Nếu hôm nay Mưa: 40% mai Nắng, 60% mai Mưa
    ]
    
    # Ngày đầu tiên chắc chắn Nắng
    pi_0 = [1.0, 0.0]
    
    pi_star = simulate_markov_chain(P, pi_0, 50)
    print("Phân phối xác suất Trạng thái dừng pi* (Nắng, Mưa):", pi_star)
    # Kết quả kỳ vọng: [0.6667, 0.3333] (Tỷ lệ xấp xỉ 2/3 Nắng, 1/3 Mưa)
