"""
LAB 7 - BÀI 5: Mô phỏng Thuật toán Google PageRank & Phân tích Điểm Nghẽn Min-Cut Mạng Máy Chủ
Môn học: AI21301 - Toán cho học máy
"""

from collections import deque

def compute_pagerank(P_web, damping_factor=0.85, max_iter=100, tol=1e-6):
    """
    Mô phỏng thuật toán Google PageRank để tính điểm số uy tín của các Server/trang web.
    Kết hợp xác suất nhảy ngẫu nhiên (Damping Factor d = 0.85) để tránh bẫy thứ hạng (Rank Sink)
    và các đỉnh cô lập (Dangling Nodes).
    
    Công thức cập nhật:
        r_new[j] = (1 - d) / N + d * sum(r[i] * P_web[i][j] for i in range(N))
        
    Parameters:
        P_web (list of list): Ma trận xác suất chuyển đổi giữa các Server kích thước N x N.
        damping_factor (float): Hệ số Damping factor (mặc định 0.85).
        max_iter (int): Số vòng lặp tối đa.
        tol (float): Ngưỡng sai số hội tụ.
        
    Returns:
        dict: Điểm số PageRank của từng server (A, B, C, D), làm tròn 4 chữ số thập phân.
    """
    n = len(P_web)
    # Khởi tạo vector phân phối điểm đồng đều ban đầu: 1/N cho mỗi node
    rank = [1.0 / n] * n
    teleport = (1.0 - damping_factor) / n
    
    for _ in range(max_iter):
        rank_next = [0.0] * n
        for j in range(n):
            rank_next[j] = teleport + damping_factor * sum(rank[i] * P_web[i][j] for i in range(n))
            
        # Kiểm tra hội tụ
        diff = sum(abs(rank_next[i] - rank[i]) for i in range(n))
        rank = rank_next
        if diff < tol:
            break
            
    server_names = ["Server A", "Server B", "Server C", "Server D"]
    return {server_names[i]: round(rank[i], 4) for i in range(n)}


def find_min_cut(capacity, s, t):
    """
    Xác định Điểm nghẽn mạng (Min-Cut) dựa trên Định lý Luồng cực đại - Lát cắt hẹp nhất
    (Max-Flow Min-Cut Theorem).
    
    Parameters:
        capacity (list of list): Ma trận dung lượng băng thông mạng giữa các Server.
        s (int): Server phát nguồn.
        t (int): Server nhận đích.
        
    Returns:
        tuple: (max_flow, set_S, set_T, cut_edges)
    """
    n = len(capacity)
    residual = [row[:] for row in capacity]
    parent = [-1] * n
    
    # BFS tìm đường tăng luồng
    def bfs():
        visited = [False] * n
        queue = deque([s])
        visited[s] = True
        while queue:
            u = queue.popleft()
            if u == t:
                return True
            for v in range(n):
                if not visited[v] and residual[u][v] > 0:
                    visited[v] = True
                    parent[v] = u
                    queue.append(v)
        return False

    max_flow = 0
    while bfs():
        bottleneck = float('inf')
        curr = t
        path = []
        while curr != s:
            prev = parent[curr]
            bottleneck = min(bottleneck, residual[prev][curr])
            path.append((prev, curr))
            curr = prev
        for u, v in path:
            residual[u][v] -= bottleneck
            residual[v][u] += bottleneck
        max_flow += bottleneck
        parent = [-1] * n

    # Tìm tập S: tất cả các đỉnh đến được từ s trên mạng thặng dư residual
    visited_residual = [False] * n
    queue = deque([s])
    visited_residual[s] = True
    while queue:
        u = queue.popleft()
        for v in range(n):
            if not visited_residual[v] and residual[u][v] > 0:
                visited_residual[v] = True
                queue.append(v)
                
    set_S = [i for i in range(n) if visited_residual[i]]
    set_T = [i for i in range(n) if not visited_residual[i]]
    
    # Tìm các cạnh lát cắt (u thuộc S, v thuộc T và capacity[u][v] > 0)
    cut_edges = []
    for u in set_S:
        for v in set_T:
            if capacity[u][v] > 0:
                cut_edges.append((u, v, capacity[u][v]))
                
    return max_flow, set_S, set_T, cut_edges


# ==============================================================================
# PHÂN TÍCH Ý NGHĨA HỌC MÁY (MACHINE LEARNING INSIGHT)
# ==============================================================================
# Vì sao trạng thái dừng của chuỗi Markov trong PageRank bản chất chính là
# Vector riêng ứng với Trị riêng lambda = 1 của ma trận chuyển vị P^T?
#
# 1. Phương trình Trạng thái dừng:
#    - Phân phối dừng pi* (dưới dạng vector hàng) thỏa mãn:
#      pi* = pi* * P
#    - Lấy chuyển vị cả 2 vế của phương trình trên:
#      (pi*)^T = (pi* * P)^T = P^T * (pi*)^T
#    - Đặt vector cột v = (pi*)^T, ta có phương trình:
#      P^T * v = 1 * v
#
# 2. Mối liên hệ với Trị riêng và Vector riêng:
#    - Phương trình A * v = lambda * v là phương trình cơ bản của đại số tuyến tính
#      xác định vector riêng v và trị riêng lambda của ma trận A.
#    - So sánh với P^T * v = 1 * v, ta thấy ngay rằng v = (pi*)^T chính là
#      Vector riêng (Eigenvector) tương ứng với Trị riêng lambda = 1 của ma trận P^T!
#
# 3. Thuật toán Lặp lũy thừa (Power Iteration):
#    - Theo Định lý Perron-Frobenius đối với ma trận ngẫu nhiên (Stochastic Matrix),
#      trị riêng có độ lớn cực đại luôn là lambda_max = 1.
#    - Quá trình lặp pi_{k+1} = pi_k * P trong PageRank chính là thuật toán Power Iteration
#      được sử dụng để tìm vector riêng ứng với trị riêng trội nhất (dominant eigenvalue)
#      của ma trận P^T.
# ==============================================================================


# Chạy thử nghiệm với test case mẫu
if __name__ == "__main__":
    # 1. Ma trận liên kết chuyển đổi giữa các Server
    P_web = [
        [0.0, 0.5, 0.5, 0.0],  # A liên kết đến B, C
        [0.0, 0.0, 1.0, 0.0],  # B liên kết đến C
        [1.0, 0.0, 0.0, 0.0],  # C liên kết đến A
        [0.0, 0.5, 0.5, 0.0]   # D liên kết đến B, C
    ]

    print("--- 1. MÔ PHỎNG GOOGLE PAGERANK CHO 4 MÁY CHỦ ---")
    ranks = compute_pagerank(P_web, damping_factor=0.85, max_iter=100)
    for server, score in ranks.items():
        print(f"{server}: {score}")

    # 2. Xác định Điểm nghẽn Min-Cut mạng máy chủ
    # Giả sử ma trận băng thông dung lượng giữa 4 Server (A:0, B:1, C:2, D:3)
    # Tìm điểm nghẽn từ Server A (0) truyền dữ liệu đến Server D (3)
    network_capacity = [
        [0, 10, 10,  0],  # A (0)
        [0,  0,  2,  8],  # B (1)
        [0,  0,  0,  9],  # C (2)
        [0,  0,  0,  0]   # D (3)
    ]
    
    server_labels = ["Server A", "Server B", "Server C", "Server D"]
    max_flow, S, T, cut_edges = find_min_cut(network_capacity, s=0, t=3)
    
    print("\n--- 2. PHÂN TÍCH ĐIỂM NGHẼN MẠNG (MIN-CUT) ---")
    print(f"Băng thông tối đa (Max Flow): {max_flow} Gbps")
    print(f"Tập Server nguồn S: {[server_labels[i] for i in S]}")
    print(f"Tập Server đích T:   {[server_labels[i] for i in T]}")
    print("Các đường cáp mạng chịu tải trọng yếu nhất (Min-Cut Bottlenecks):")
    for u, v, cap in cut_edges:
        print(f" - Cáp từ {server_labels[u]} -> {server_labels[v]} (Dung lượng: {cap} Gbps)")
