"""
LAB 7 - BÀI 3: Cài đặt Thuật toán Ford-Fulkerson Tìm Luồng Cực đại (Max-Flow)
Môn học: AI21301 - Toán cho học máy
"""

from collections import deque

def bfs_find_path(residual, s, t, parent):
    """
    Sử dụng BFS tìm đường tăng luồng (Augmenting Path) từ s đến t
    trên mạng thặng dư residual có residual[u][v] > 0.
    
    Parameters:
        residual (list of list): Ma trận mạng thặng dư.
        s (int): Đỉnh nguồn (source).
        t (int): Đỉnh thu (sink).
        parent (list): Mảng lưu đỉnh cha trên đường đi.
        
    Returns:
        bool: True nếu tìm thấy đường đi từ s đến t, ngược lại False.
    """
    n = len(residual)
    visited = [False] * n
    queue = deque([s])
    visited[s] = True
    
    while queue:
        u = queue.popleft()
        if u == t:
            return True
            
        for v in range(n):
            if not visited[v] and residual[u][v] > 0:
                visited[v] = True
                parent[v] = u
                queue.append(v)
                
    return False


def ford_fulkerson(C, s, t):
    """
    Thuật toán Ford-Fulkerson (biến thể Edmonds-Karp sử dụng BFS)
    để tìm Luồng cực đại (Max-Flow) trên mạng luồng.
    
    Parameters:
        C (list of list): Ma trận dung lượng khả năng thông qua (Capacity matrix) kích thước N x N.
        s (int): Đỉnh phát (Source).
        t (int): Đỉnh thu (Sink).
        
    Returns:
        int/float: Giá trị luồng cực đại (Max Flow).
    """
    n = len(C)
    # 1. Khởi tạo ma trận thặng dư và biến luồng cực đại
    residual = [row[:] for row in C]
    parent = [-1] * n
    max_flow = 0
    
    # 2. Lặp lại việc tìm đường tăng luồng
    step = 1
    while bfs_find_path(residual, s, t, parent):
        # 3. Tìm dung lượng nghẽn (bottleneck) trên đường đi vừa tìm được
        bottleneck = float('inf')
        curr = t
        path = []
        while curr != s:
            prev = parent[curr]
            bottleneck = min(bottleneck, residual[prev][curr])
            path.append((prev, curr))
            curr = prev
            
        path.reverse()
        
        # 4. Cập nhật mạng thặng dư: cạnh thuận giảm, cạnh nghịch tăng
        for u, v in path:
            residual[u][v] -= bottleneck
            residual[v][u] += bottleneck
            
        # 5. Cộng dồn vào luồng cực đại
        max_flow += bottleneck
        print(f"Bước {step}: Đường tăng luồng {[u for u, v in path] + [t]} với bottleneck = {bottleneck}, Flow hiện tại = {max_flow}")
        step += 1
        
        # Reset mảng parent cho lần tìm tiếp theo
        parent = [-1] * n
        
    return max_flow


# Chạy thử nghiệm với test case mẫu
if __name__ == "__main__":
    # Ma trận dung lượng C (4 đỉnh: 0, 1, 2, 3)
    # Đỉnh phát s = 0, đỉnh thu t = 3
    C = [
        [0, 10, 10,  0],  # s (0)
        [0,  0,  2,  8],  # u (1)
        [0,  0,  0,  9],  # v (2)
        [0,  0,  0,  0]   # t (3)
    ]
    s = 0
    t = 3

    print("--- CHẠY THUẬT TOÁN FORD-FULKERSON ---")
    result_flow = ford_fulkerson(C, s, t)
    print(f"\nLuồng cực đại Max Flow (từ {s} đến {t}): {result_flow}")
    # Kết quả kỳ vọng: Luồng cực đại Max Flow = 17
