"""
LAB 7 - BÀI 4: Quy đổi Bài toán Cặp ghép Cực đại (Maximum Matching) sang Luồng Cực đại
Môn học: AI21301 - Toán cho học máy
"""

from collections import deque

def bfs_find_path(residual, s, t, parent):
    """BFS tìm đường tăng luồng từ s đến t."""
    n = len(residual)
    visited = [False] * n
    queue = deque([s])
    visited[s] = True
    
    while queue:
        u = queue.popleft()
        if u == t:
            return True
        for v in range(n):
            if not visited[v] and residual[u][v] > 0:
                visited[v] = True
                parent[v] = u
                queue.append(v)
    return False


def ford_fulkerson_with_flow(C, s, t):
    """
    Thuật toán Ford-Fulkerson trả về cả luồng cực đại và ma trận luồng thực tế.
    """
    n = len(C)
    residual = [row[:] for row in C]
    parent = [-1] * n
    max_flow = 0
    
    while bfs_find_path(residual, s, t, parent):
        bottleneck = float('inf')
        curr = t
        path = []
        while curr != s:
            prev = parent[curr]
            bottleneck = min(bottleneck, residual[prev][curr])
            path.append((prev, curr))
            curr = prev
            
        for u, v in path:
            residual[u][v] -= bottleneck
            residual[v][u] += bottleneck
            
        max_flow += bottleneck
        parent = [-1] * n
        
    # Ma trận luồng thực tế: flow[u][v] = C[u][v] - residual[u][v] (cho các cạnh có C[u][v] > 0)
    flow = [[0] * n for _ in range(n)]
    for u in range(n):
        for v in range(n):
            if C[u][v] > 0:
                flow[u][v] = C[u][v] - residual[u][v]
                
    return max_flow, flow


def solve_bipartite_matching(L, R, candidate_edges):
    """
    Quy đổi bài toán Cặp ghép cực đại trên đồ thị hai phía sang bài toán Luồng cực đại:
    - Tạo đỉnh phát s = 4 và đỉnh thu t = 5.
    - Cạnh từ s -> u (u thuộc L) với dung lượng 1.
    - Cạnh từ u -> v (u thuộc L, v thuộc R theo candidate_edges) với dung lượng 1.
    - Cạnh từ v -> t (v thuộc R) với dung lượng 1.
    
    Parameters:
        L (iterable): Tập ứng viên (ví dụ {0, 1}).
        R (iterable): Tập công việc (ví dụ {2, 3}).
        candidate_edges (list of tuple): Các cạnh ghép khả dĩ (ứng_viên, công_việc).
        
    Returns:
        int: Số lượng cặp ghép tối đa.
    """
    s = 4  # Đỉnh phát
    t = 5  # Đỉnh thu
    total_nodes = 6
    
    # Khởi tạo ma trận dung lượng kích thước 6 x 6
    C = [[0] * total_nodes for _ in range(total_nodes)]
    
    # 1. Nối s -> u (u thuộc L) có dung lượng c = 1
    for u in L:
        C[s][u] = 1
        
    # 2. Nối u -> v (u thuộc L, v thuộc R theo candidate_edges) có dung lượng c = 1
    for u, v in candidate_edges:
        C[u][v] = 1
        
    # 3. Nối v -> t (v thuộc R) có dung lượng c = 1
    for v in R:
        C[v][t] = 1
        
    # 4. Chạy Ford-Fulkerson từ s đến t
    max_matching, flow = ford_fulkerson_with_flow(C, s, t)
    
    # Tìm các cặp ghép thực tế (các cạnh giữa L và R có flow == 1)
    matched_pairs = []
    for u, v in candidate_edges:
        if flow[u][v] == 1:
            matched_pairs.append((u, v))
            
    print(f"Các cặp ghép tối ưu tìm được: {matched_pairs}")
    return max_matching


# Chạy thử nghiệm với test case mẫu
if __name__ == "__main__":
    # Tập ứng viên L = {0, 1}, tập công việc R = {2, 3}
    L = [0, 1]
    R = [2, 3]
    
    # Ứng viên 0 làm được {2, 3}, Ứng viên 1 làm được {2}
    candidate_edges = [(0, 2), (0, 3), (1, 2)]
    
    max_match = solve_bipartite_matching(L, R, candidate_edges)
    print(f"Kết quả số cặp ghép tối đa: {max_match}")
    # Kết quả kỳ vọng: 2 (Ghép 0-3 và 1-2)
