"""
LAB 7 - BÀI 2: Kiểm tra Đồ thị Hai phía (Bipartite Graph) bằng BFS Tô 2 Màu
Môn học: AI21301 - Toán cho học máy
"""

from collections import deque

def is_bipartite_bfs(adj_list, num_nodes):
    """
    Kiểm tra xem một đồ thị vô hướng có phải là đồ thị hai phía (Bipartite Graph)
    hay không bằng thuật toán BFS tô 2 màu (0 và 1).
    Một đồ thị là hai phía khi và chỉ khi nó không chứa chu trình có độ dài lẻ.
    
    Parameters:
        adj_list (dict): Danh sách kề của đồ thị.
        num_nodes (int): Số đỉnh của đồ thị (từ 0 đến num_nodes - 1).
        
    Returns:
        bool: True nếu là đồ thị hai phía, False nếu có xung đột màu.
    """
    # Bước 1: Khởi tạo từ điển lưu màu của từng đỉnh (color = {})
    color = {}  # 0 hoặc 1
    
    # Duyệt qua các đỉnh từ 0 đến N-1 (xử lý trường hợp đồ thị có nhiều thành phần rời rạc)
    for start in range(num_nodes):
        if start in color:
            continue
            
        # Bước 2: Gán màu cho đỉnh xuất phát và đưa vào hàng đợi BFS
        queue = deque([start])
        color[start] = 0
        
        # Bước 3: Duyệt BFS
        while queue:
            u = queue.popleft()
            for v in adj_list.get(u, []):
                # Bước 4: Nếu v chưa có màu, tô màu đối lập (1 - color[u])
                if v not in color:
                    color[v] = 1 - color[u]
                    queue.append(v)
                # Bước 5: Nếu v đã có màu và cùng màu với u -> Xung đột màu!
                elif color[v] == color[u]:
                    return False
                    
    # Bước 6: Không có xung đột màu trên toàn bộ đồ thị
    return True


# Chạy thử nghiệm với các test case mẫu
if __name__ == "__main__":
    # Test case 1: Chu trình 4 đỉnh (độ dài chẵn 4) -> Là đồ thị hai phía
    g_even = {0: [1, 3], 1: [0, 2], 2: [1, 3], 3: [0, 2]}
    print("g_even là đồ thị hai phía:", is_bipartite_bfs(g_even, 4))  # Kỳ vọng: True

    # Test case 2: Chu trình 3 đỉnh (tam giác lẻ 3) -> Không phải hai phía
    g_odd = {0: [1, 2], 1: [0, 2], 2: [0, 1]}
    print("g_odd là đồ thị hai phía:", is_bipartite_bfs(g_odd, 3))    # Kỳ vọng: False
