"""
LAB 3 - BÀI 2: Tính lũy thừa nhanh Ma trận bằng Chéo hóa (Matrix Power via Diagonalization)
A = P · D · P^(-1)   =>   A^k = P · D^k · P^(-1)
Ví dụ: A = [[4, 2], [1, 3]] có trị riêng 5, 2 với vector riêng [2, 1] và [1, -1].
  => P = [[2, 1], [1, -1]] (các vector riêng xếp theo CỘT), D = diag(5, 2).
"""


def mat_mul_2x2(X, Y):
    """Nhân hai ma trận 2x2."""
    return [[X[0][0] * Y[0][0] + X[0][1] * Y[1][0], X[0][0] * Y[0][1] + X[0][1] * Y[1][1]],
            [X[1][0] * Y[0][0] + X[1][1] * Y[1][0], X[1][0] * Y[0][1] + X[1][1] * Y[1][1]]]


def inverse_2x2(M):
    """Ma trận nghịch đảo 2x2: M^-1 = (1/det) * [[d, -b], [-c, a]]."""
    a, b = M[0]
    c, d = M[1]
    det = a * d - b * c
    if abs(det) < 1e-12:
        raise ValueError("Ma trận suy biến, không khả nghịch.")
    return [[d / det, -b / det],
            [-c / det, a / det]]


def matrix_power_fast(P, D_diag, P_inv, k):
    """Tính A^k = P · D^k · P^(-1)."""
    # Bước 1 + 2: D^k chỉ cần lũy thừa từng phần tử trên đường chéo
    D_k = [[D_diag[0] ** k, 0.0],
           [0.0, D_diag[1] ** k]]
    # Bước 3: Nhân 3 ma trận P · D_k · P_inv
    return mat_mul_2x2(mat_mul_2x2(P, D_k), P_inv)


def matrix_power_naive(A, k):
    """Cách thông thường: nhân A với chính nó k lần (để đối chiếu)."""
    result = [[1, 0], [0, 1]]
    for _ in range(k):
        result = mat_mul_2x2(result, A)
    return result


def clean(M, nd=4):
    return [[round(v, nd) + 0.0 for v in row] for row in M]


# -------------------------------------------------------------------------------------
# Nhận xét độ phức tạp:
#  - Cách thông thường: k lần nhân ma trận n x n -> O(k · n^3).
#  - Chéo hóa: chỉ lũy thừa n số trên đường chéo (O(n · log k) nếu dùng lũy thừa nhanh)
#    + 2 phép nhân ma trận -> O(n^3 + n·log k), gần như không phụ thuộc vào k.
#  - Ứng dụng: trạng thái dài hạn của chuỗi Markov (P^k), phân tích gradient bùng nổ /
#    triệt tiêu trong RNN (|lambda| > 1 hay < 1 khi nhân trọng số nhiều lần).
# -------------------------------------------------------------------------------------


if __name__ == "__main__":
    A = [[4, 2], [1, 3]]
    P = [[2, 1],
         [1, -1]]
    D_diag = [5, 2]
    P_inv = inverse_2x2(P)

    print("P     =", P)
    print("P_inv =", clean(P_inv))

    # Kiểm chứng: P · D · P^-1 phải bằng A
    print("P·D·P^-1 =", clean(matrix_power_fast(P, D_diag, P_inv, 1)), " (phải bằng A =", A, ")")

    for k in [2, 5, 10]:
        fast = clean(matrix_power_fast(P, D_diag, P_inv, k))
        naive = matrix_power_naive(A, k)
        print(f"\nA^{k} (chéo hóa)    = {fast}")
        print(f"A^{k} (nhân k lần)  = {naive}")
        print("Khớp nhau:", all(abs(fast[i][j] - naive[i][j]) < 1e-3 for i in range(2) for j in range(2)))
