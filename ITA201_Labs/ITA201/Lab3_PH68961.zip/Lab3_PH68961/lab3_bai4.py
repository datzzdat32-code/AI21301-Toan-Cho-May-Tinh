"""
LAB 3 - BÀI 4: Chiếu dữ liệu lên Thành phần chính (Projection onto Principal Component)
z_i = <X_centered[i], pc_vector>, với ||pc_vector|| = 1.
"""


def project_data_1d(X_centered, pc_vector, eps=1e-6):
    """Trả về danh sách M tọa độ mới (1D) của dữ liệu trên trục pc_vector."""
    N = len(pc_vector)
    if len(X_centered[0]) != N:
        raise ValueError("Số cột của X_centered phải bằng số chiều của pc_vector.")

    # Kiểm tra vector đã chuẩn hóa (độ dài = 1); nếu chưa thì tự chuẩn hóa
    norm = sum(v * v for v in pc_vector) ** 0.5
    if abs(norm - 1) > eps:
        print(f"Cảnh báo: ||pc_vector|| = {norm:.4f} khác 1, tự động chuẩn hóa.")
        pc_vector = [v / norm for v in pc_vector]

    projected = []
    for row in X_centered:
        projected.append(sum(row[j] * pc_vector[j] for j in range(N)))
    return projected


if __name__ == "__main__":
    # Dữ liệu đã trừ trung bình (từ X = [[1,2],[3,4],[5,6]] ở Bài 3)
    X_centered = [[-2, -2],
                  [0, 0],
                  [2, 2]]
    pc1 = [1 / 2 ** 0.5, 1 / 2 ** 0.5]   # vector riêng chuẩn hóa ứng với trị riêng lớn nhất (8)

    z = project_data_1d(X_centered, pc1)
    print("Tọa độ trên PC1:", [round(v, 4) + 0.0 for v in z])   # [-2.8284, 0.0, 2.8284]

    # Kiểm chứng: phương sai dữ liệu sau chiếu = trị riêng lambda1 = 8
    var_z = sum(v * v for v in z) / (len(z) - 1)
    print(f"Phương sai sau khi chiếu: {var_z:.4f} (= trị riêng lớn nhất của Cov = 8)")

    # Chiếu lên trục vuông góc PC2 = [-1/√2, 1/√2]: toàn bộ bằng 0 -> không mất thông tin
    pc2 = [-1 / 2 ** 0.5, 1 / 2 ** 0.5]
    print("Tọa độ trên PC2:", [round(v, 4) + 0.0 for v in project_data_1d(X_centered, pc2)])

    # Test vector chưa chuẩn hóa
    print("\nTest pc_vector = [1, 1] (chưa chuẩn hóa):")
    print("Tọa độ:", [round(v, 4) + 0.0 for v in project_data_1d(X_centered, [1, 1])])
