"""
LAB 3 - BÀI 5: Pipeline Giảm chiều Dữ liệu Bệnh án & Tỷ lệ Phương sai giải thích (Explained Variance)
Quy trình PCA: Trừ trung bình -> Ma trận hiệp phương sai 4x4 -> Trị riêng/Vector riêng
               -> Chọn 2 vector riêng lớn nhất (PC1, PC2) -> Chiếu dữ liệu 4D về 2D.
Trị riêng của ma trận đối xứng 4x4 được tính bằng thuật toán Jacobi (Python thuần, không numpy).
"""
import math

FEATURES = ["Huyết áp", "Đường huyết", "Cholesterol", "BMI"]


# ---------------------------- Các bước nền tảng (Bài 3, 4) ----------------------------
def mean_centering(X):
    M, N = len(X), len(X[0])
    means = [sum(X[i][j] for i in range(M)) / M for j in range(N)]
    return [[X[i][j] - means[j] for j in range(N)] for i in range(M)]


def compute_covariance_matrix(Xc):
    M, N = len(Xc), len(Xc[0])
    Cov = [[0.0] * N for _ in range(N)]
    for i in range(N):
        for j in range(i, N):
            Cov[i][j] = Cov[j][i] = sum(Xc[k][i] * Xc[k][j] for k in range(M)) / (M - 1)
    return Cov


def project(Xc, v):
    return [sum(row[j] * v[j] for j in range(len(v))) for row in Xc]


# ------------------------- Thuật toán Jacobi tìm trị riêng ---------------------------
def mat_mul(A, B):
    n, m, p = len(A), len(B), len(B[0])
    return [[sum(A[i][k] * B[k][j] for k in range(m)) for j in range(p)] for i in range(n)]


def transpose(A):
    return [list(r) for r in zip(*A)]


def jacobi_eigen(S, eps=1e-12, max_iter=1000):
    """
    Tìm trị riêng và vector riêng của ma trận ĐỐI XỨNG S.
    Ý tưởng: lặp lại phép xoay J^T·A·J để triệt tiêu phần tử ngoài đường chéo lớn nhất,
    đến khi A gần như chéo. Khi đó: đường chéo của A = các trị riêng,
    các CỘT của V = J1·J2·...·Jk = các vector riêng (đã chuẩn hóa, trực giao).
    """
    n = len(S)
    A = [row[:] for row in S]
    V = [[1.0 if i == j else 0.0 for j in range(n)] for i in range(n)]

    for _ in range(max_iter):
        # Tìm phần tử ngoài đường chéo có trị tuyệt đối lớn nhất
        p, q, max_val = 0, 1, 0.0
        for i in range(n):
            for j in range(i + 1, n):
                if abs(A[i][j]) > max_val:
                    p, q, max_val = i, j, abs(A[i][j])
        if max_val < eps:
            break

        # Góc xoay theta thỏa tan(2θ) = 2·A[p][q] / (A[q][q] - A[p][p])
        theta = 0.5 * math.atan2(2 * A[p][q], A[q][q] - A[p][p])
        c, s = math.cos(theta), math.sin(theta)
        J = [[1.0 if i == j else 0.0 for j in range(n)] for i in range(n)]
        J[p][p], J[q][q] = c, c
        J[p][q], J[q][p] = s, -s

        A = mat_mul(mat_mul(transpose(J), A), J)
        V = mat_mul(V, J)

    eigenvalues = [A[i][i] for i in range(n)]
    eigenvectors = [[V[r][c] for r in range(n)] for c in range(n)]  # lấy theo cột

    # Sắp xếp giảm dần theo trị riêng
    order = sorted(range(n), key=lambda i: eigenvalues[i], reverse=True)
    eigenvalues = [eigenvalues[i] for i in order]
    eigenvectors = [eigenvectors[i] for i in order]

    # Chuẩn hóa dấu (thành phần có |giá trị| lớn nhất mang dấu dương) để kết quả ổn định
    for idx, v in enumerate(eigenvectors):
        if max(v, key=abs) < 0:
            eigenvectors[idx] = [-x for x in v]
    return eigenvalues, eigenvectors


# ------------------------------------ Pipeline PCA -----------------------------------
def pca_reduce_2d(data):
    """
    Trả về:
      Z           : dữ liệu sau giảm chiều (M x 2), mỗi hàng là [tọa độ PC1, tọa độ PC2]
      eigenvalues : toàn bộ trị riêng của ma trận hiệp phương sai (giảm dần)
      components  : [PC1, PC2] (vector riêng chuẩn hóa)
      Cov         : ma trận hiệp phương sai 4x4
    """
    Xc = mean_centering(data)                  # 1. Trừ trung bình
    Cov = compute_covariance_matrix(Xc)        # 2. Ma trận hiệp phương sai 4x4
    eigenvalues, eigenvectors = jacobi_eigen(Cov)  # 3. Trị riêng / vector riêng
    pc1, pc2 = eigenvectors[0], eigenvectors[1]    # 4. Chọn 2 thành phần chính lớn nhất
    z1, z2 = project(Xc, pc1), project(Xc, pc2)    # 5. Chiếu dữ liệu
    Z = [[z1[i], z2[i]] for i in range(len(data))]
    return Z, eigenvalues, [pc1, pc2], Cov


def explained_variance_ratio(lambdas, k=2):
    """Tỷ lệ phương sai giải thích bởi k thành phần đầu: sum(lambda_1..k) / sum(lambda)."""
    return sum(lambdas[:k]) / sum(lambdas)


def r(v, nd=4):
    return round(v, nd) + 0.0


if __name__ == "__main__":
    medical_data = [
        [120, 95, 210, 24.5],
        [140, 130, 250, 29.0],
        [110, 85, 180, 21.5],
        [155, 160, 280, 32.0],
        [130, 105, 220, 26.0]
    ]

    Z, eigvals, (pc1, pc2), Cov = pca_reduce_2d(medical_data)

    print("Ma trận hiệp phương sai 4x4:")
    for row in Cov:
        print("  ", [r(v, 2) for v in row])

    print("\nTrị riêng (giảm dần):", [r(v) for v in eigvals])
    print("Kiểm tra: tổng trị riêng =", r(sum(eigvals), 3),
          "| vết (trace) của Cov =", r(sum(Cov[i][i] for i in range(4)), 3))

    print("\nPC1 =", [r(v) for v in pc1])
    print("PC2 =", [r(v) for v in pc2])
    # Kiểm chứng vector riêng: Cov·v = lambda·v
    for name, v, lam in [("PC1", pc1, eigvals[0]), ("PC2", pc2, eigvals[1])]:
        Cv = [sum(Cov[i][j] * v[j] for j in range(4)) for i in range(4)]
        ok = all(abs(Cv[i] - lam * v[i]) < 1e-6 for i in range(4))
        print(f"  {name}: Cov·v = lambda·v -> {ok}")

    print("\nDữ liệu sau khi giảm chiều 4D -> 2D:")
    print("  Bệnh nhân |     PC1     |    PC2")
    for i, (a, b) in enumerate(Z):
        print(f"      {i + 1}     | {a:10.4f}  | {b:8.4f}")

    # ---------------- Tỷ lệ phương sai giải thích với lambda cho trong đề ----------------
    lambda_given = [145.2, 32.8, 4.5, 1.2]
    ratio = explained_variance_ratio(lambda_given, 2)
    print(f"\n[Theo đề] lambda = {lambda_given}")
    print(f"Ratio = (145.2 + 32.8) / {sum(lambda_given):.1f} = {ratio:.4f} -> {ratio * 100:.2f}%")

    # Đối chiếu với trị riêng thực tế tính từ dữ liệu
    ratio_real = explained_variance_ratio(eigvals, 2)
    print(f"[Từ dữ liệu thực] Ratio = {ratio_real:.6f} -> {ratio_real * 100:.4f}%")

# =====================================================================================
# PHÂN TÍCH Ý NGHĨA HỌC MÁY
# 1) Tỷ lệ thông tin > 90% (theo đề: 96.90%) thì loại bỏ 2 chiều cuối có làm mất bản chất
#    dữ liệu không?
#    -> KHÔNG làm mất bản chất. PC1 + PC2 đã giữ lại ~96.9% tổng phương sai; hai trục bị bỏ
#       chỉ chứa ~3.1% (lambda3 = 4.5, lambda4 = 1.2), chủ yếu là nhiễu đo đạc hoặc dao động
#       nhỏ. Bốn chỉ số (huyết áp, đường huyết, cholesterol, BMI) tương quan dương rất mạnh,
#       cùng tăng/giảm theo "mức độ rủi ro chuyển hóa" của bệnh nhân, nên thông tin bị trùng
#       lặp nhiều -> nén về 2 chiều vẫn giữ nguyên cấu trúc chính: thứ tự, khoảng cách tương
#       đối và các cụm bệnh nhân.
#    -> Lưu ý: (a) phương sai nhỏ KHÔNG luôn đồng nghĩa với không quan trọng – một bất thường
#       hiếm gặp có thể nằm ở PC3/PC4, nên vẫn giữ dữ liệu gốc cho chẩn đoán; (b) các chỉ số
#       có đơn vị khác nhau (cholesterol có phương sai lớn nhất sẽ chi phối PC1), thực tế nên
#       chuẩn hóa z-score trước khi làm PCA; (c) PCA chỉ nắm bắt quan hệ tuyến tính.
# 2) Lợi ích khi trực quan hóa 2D cho chuyên gia y tế:
#    - Mỗi bệnh nhân là một điểm trên mặt phẳng: dễ quan sát các nhóm bệnh nhân tương đồng,
#      nhóm nguy cơ cao/thấp và các ca ngoại lai (outlier) cần kiểm tra lại.
#    - PC1 có thể diễn giải như một "chỉ số nguy cơ chuyển hóa tổng hợp" (các thành phần của
#      PC1 cùng dấu) -> bác sĩ xếp hạng rủi ro bằng một con số thay vì 4 chỉ số rời rạc.
#    - Theo dõi một bệnh nhân qua nhiều lần khám như một quỹ đạo trên đồ thị 2D.
#    - Giao tiếp kết quả dễ hiểu hơn cho người không chuyên về dữ liệu, đồng thời giảm số
#      chiều giúp các mô hình phía sau (phân cụm, phân loại) chạy nhanh hơn, ít overfitting.
# =====================================================================================
