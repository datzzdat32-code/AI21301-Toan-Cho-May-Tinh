"""
LAB 3 - BÀI 1: Xác thực Trị riêng & Vector riêng (Eigenvalue & Eigenvector Verification)
x (khác 0) là vector riêng của A ứng với trị riêng lambda  <=>  A·x = lambda·x
"""


def verify_eigen(A, x, lambda_val, eps=1e-6):
    """Trả về (True/False, A·x, lambda·x)."""
    n = len(A)

    # Vector 0 không bao giờ được coi là vector riêng
    if all(abs(v) < eps for v in x):
        return False, [0] * n, [0] * n

    # Bước 1: Vế trái LHS = A·x
    Ax = []
    for i in range(n):
        Ax.append(sum(A[i][j] * x[j] for j in range(len(x))))

    # Bước 2: Vế phải RHS = lambda·x
    lambda_x = [lambda_val * val for val in x]

    # Bước 3 + 4: So sánh với sai số eps
    is_valid = all(abs(Ax[i] - lambda_x[i]) < eps for i in range(n))
    return is_valid, Ax, lambda_x


if __name__ == "__main__":
    A = [[4, 2],
         [1, 3]]

    # Test case trong đề
    is_valid, Ax, lambda_x = verify_eigen(A, [2, 1], 5)
    print(f"Ax: {Ax} | Lambda*x: {lambda_x}")
    print(f"x là vector riêng: {is_valid}")  # True

    # Test bổ sung
    # Đa thức đặc trưng: det(A - λI) = λ^2 - 7λ + 10 = 0  =>  λ1 = 5, λ2 = 2
    print("\nTest bổ sung:")
    for x, lam in [([1, -1], 2),   # vector riêng ứng với λ = 2 -> True
                   ([4, 2], 5),    # bội của [2, 1] cũng là vector riêng -> True
                   ([1, 1], 5),    # không phải vector riêng -> False
                   ([2, 1], 2)]:   # đúng hướng nhưng sai trị riêng -> False
        ok, Ax, lx = verify_eigen(A, x, lam)
        print(f"  x = {x}, lambda = {lam}: Ax = {Ax}, lambda*x = {lx} -> {ok}")
