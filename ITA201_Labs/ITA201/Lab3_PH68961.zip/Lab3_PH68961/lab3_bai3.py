"""
LAB 3 - BÀI 3: Trừ trung bình & Ma trận Hiệp phương sai (Mean Centering & Covariance Matrix)
  X_centered[i][j] = X[i][j] - mean_j
  Cov[i][j] = sum_k X_centered[k][i] * X_centered[k][j] / (M - 1)
"""


def mean_centering(X):
    """X: M hàng (mẫu), N cột (đặc trưng). Trả về X_centered (mỗi cột có trung bình 0)."""
    M = len(X)
    N = len(X[0])

    # Tính trung bình từng cột
    means = [0.0] * N
    for row in X:
        for j in range(N):
            means[j] += row[j]
    means = [s / M for s in means]

    # Trừ trung bình
    X_centered = [[X[i][j] - means[j] for j in range(N)] for i in range(M)]
    return X_centered


def compute_covariance_matrix(X_centered):
    """Tính ma trận hiệp phương sai N x N (chia cho M - 1, ước lượng không chệch)."""
    M = len(X_centered)
    N = len(X_centered[0])
    if M < 2:
        raise ValueError("Cần ít nhất 2 mẫu dữ liệu để tính hiệp phương sai.")

    Cov = [[0.0] * N for _ in range(N)]
    for i in range(N):
        for j in range(i, N):                    # ma trận đối xứng: chỉ tính nửa trên
            s = sum(X_centered[k][i] * X_centered[k][j] for k in range(M))
            Cov[i][j] = s / (M - 1)
            Cov[j][i] = Cov[i][j]
    return Cov


def print_matrix(M, nd=4):
    for row in M:
        print("  ", [round(v, nd) + 0.0 for v in row])


if __name__ == "__main__":
    # Test 1: ví dụ dễ kiểm tra bằng tay
    X = [[1, 2],
         [3, 4],
         [5, 6]]
    Xc = mean_centering(X)
    print("Test 1 - X_centered:")
    print_matrix(Xc)                    # [[-2,-2],[0,0],[2,2]]
    print("Ma trận hiệp phương sai:")
    print_matrix(compute_covariance_matrix(Xc))  # [[4,4],[4,4]]

    # Test 2: dữ liệu 5 mẫu x 3 đặc trưng
    X2 = [[2.5, 2.4, 1.0],
          [0.5, 0.7, 2.1],
          [2.2, 2.9, 0.8],
          [1.9, 2.2, 1.5],
          [3.1, 3.0, 0.4]]
    Xc2 = mean_centering(X2)
    col_means = [round(sum(r[j] for r in Xc2) / len(Xc2), 10) + 0.0 for j in range(3)]
    print("\nTest 2 - Trung bình các cột sau khi trừ trung bình:", col_means)
    Cov2 = compute_covariance_matrix(Xc2)
    print("Ma trận hiệp phương sai 3x3:")
    print_matrix(Cov2)
    print("Đối xứng:", all(Cov2[i][j] == Cov2[j][i] for i in range(3) for j in range(3)))
    print("(Đường chéo = phương sai từng đặc trưng; Cov < 0 -> hai đặc trưng biến thiên ngược chiều)")
