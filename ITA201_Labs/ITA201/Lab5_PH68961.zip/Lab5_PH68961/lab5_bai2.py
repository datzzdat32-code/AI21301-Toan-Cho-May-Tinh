"""
LAB 5 - BÀI 2: Tính Độ tăng thông tin (Information Gain) cho Thuật toán Cây quyết định
Môn học: AI21301 - Toán cho học máy
"""

import math

def compute_entropy(labels):
    """
    Tính Shannon Entropy H(D) theo đơn vị bit.
    """
    if not labels:
        return 0.0
    total_samples = len(labels)
    label_counts = {}
    for label in labels:
        label_counts[label] = label_counts.get(label, 0) + 1
    entropy = 0.0
    for count in label_counts.values():
        p = count / total_samples
        if p > 0:
            entropy -= p * math.log2(p)
    return round(entropy, 4)

def compute_information_gain(parent_labels, subsets_labels):
    """
    Tính Độ tăng thông tin (Information Gain - IG) khi chia tập nhãn cha thành các tập con:
    IG(D, A) = H(D) - H(D|A)
    
    Parameters:
        parent_labels (list): Danh sách nhãn của tập dữ liệu cha.
        subsets_labels (list of list): Danh sách các tập nhãn con sau khi chia theo thuộc tính.
        
    Returns:
        float: Giá trị Information Gain làm tròn 4 chữ số thập phân.
    """
    # Bước 1: Tính Entropy của tập nhãn cha (H_parent)
    h_parent = compute_entropy(parent_labels)
    total_len = len(parent_labels)
    
    if total_len == 0:
        return 0.0
        
    # Bước 2: Tính Entropy có điều kiện sau chia (H_children)
    h_children = 0.0
    for sub in subsets_labels:
        if len(sub) > 0:
            weight = len(sub) / total_len
            h_children += weight * compute_entropy(sub)
            
    # Bước 3: Tính Information Gain (IG = H_parent - H_children)
    ig = h_parent - h_children
    return round(ig, 4)


# Chạy thử nghiệm với test case mẫu
if __name__ == "__main__":
    # Test case: Chia tập [Yes, Yes, No, No] thành 2 tập tinh khiết [Yes, Yes] và [No, No]
    parent = ['Yes', 'Yes', 'No', 'No']
    sub1 = ['Yes', 'Yes']
    sub2 = ['No', 'No']

    ig = compute_information_gain(parent, [sub1, sub2])
    print(f"Information Gain thu được: {ig} bits")
    # Kết quả kỳ vọng: 1.0 bits
