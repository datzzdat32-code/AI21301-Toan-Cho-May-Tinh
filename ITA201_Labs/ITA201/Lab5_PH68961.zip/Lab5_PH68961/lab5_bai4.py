"""
LAB 5 - BÀI 4: Hàm mất mát Binary Cross-Entropy Loss & Làm mượt Laplace (Laplace Smoothing)
Môn học: AI21301 - Toán cho học máy
"""

import math

def binary_cross_entropy(y_true, y_pred, eps=1e-15):
    """
    Tính Binary Cross-Entropy Loss:
    Loss = -(y_true * log(y_pred) + (1 - y_true) * log(1 - y_pred))
    
    Parameters:
        y_true (int/float): Nhãn thực tế (0 hoặc 1).
        y_pred (float): Xác suất dự đoán (trong khoảng 0.0 đến 1.0).
        eps (float): Ngưỡng kẹp giá trị để tránh chia cho 0 hoặc log(0).
        
    Returns:
        float: Giá trị mất mát Binary Cross-Entropy.
    """
    # Kẹp y_pred trong khoảng [eps, 1 - eps] để tránh lỗi math.log(0)
    y_pred_clipped = max(eps, min(1.0 - eps, y_pred))
    
    # Tính Loss theo công thức Binary Cross-Entropy
    loss = -(y_true * math.log(y_pred_clipped) + (1.0 - y_true) * math.log(1.0 - y_pred_clipped))
    return loss


def laplace_smoothing(count_word, count_class, vocab_size, alpha=1.0):
    """
    Tính xác suất có làm mượt Laplace (Add-1 Smoothing hoặc Add-alpha Smoothing):
    P = (count_word + alpha) / (count_class + alpha * vocab_size)
    
    Parameters:
        count_word (int): Số lần từ xuất hiện trong lớp tương ứng.
        count_class (int): Tổng số từ trong lớp đó.
        vocab_size (int): Kích thước của toàn bộ từ điển (số từ duy nhất).
        alpha (float): Hệ số làm mượt (mặc định = 1.0).
        
    Returns:
        float: Xác suất sau khi làm mượt.
    """
    prob = (count_word + alpha) / (count_class + alpha * vocab_size)
    return prob


# Chạy thử nghiệm với các test case mẫu
if __name__ == "__main__":
    # Test Loss
    loss_correct = binary_cross_entropy(1, 0.9)
    loss_wrong = binary_cross_entropy(1, 0.1)
    
    print(f"Loss khi dự đoán chuẩn (y=1, p=0.9): {loss_correct:.4f}")  # Thấp (~0.1054)
    print(f"Loss khi dự đoán sai (y=1, p=0.1): {loss_wrong:.4f}")       # Rất cao (~2.3026)

    # Test Laplace: từ chưa xuất hiện trong tập huấn luyện (count = 0)
    p_smoothed = laplace_smoothing(count_word=0, count_class=100, vocab_size=500)
    print(f"Xác suất sau làm mượt: {p_smoothed:.4f}")                    # ~0.0017 (khác 0)
