"""
LAB 5 - BÀI 3: Phân loại Xác suất Naive Bayes Đơn giản (Naive Bayes Inference)
Môn học: AI21301 - Toán cho học máy
"""

def naive_bayes_predict(dataset, x_new):
    """
    Phân loại Naive Bayes với các đặc trưng nhị phân [x1, x2].
    
    Parameters:
        dataset (list of tuple): Tập dữ liệu gồm các cặp (features, label),
                                 ví dụ ([1, 1], 1).
        x_new (list): Mẫu dữ liệu mới cần dự đoán nhãn, ví dụ [1, 0].
        
    Returns:
        int: Nhãn dự đoán (1: Spam, 0: Thường).
    """
    total_samples = len(dataset)
    if total_samples == 0:
        return None
        
    # Tách dữ liệu theo nhãn Y = 1 và Y = 0
    class_1 = [x for x, y in dataset if y == 1]
    class_0 = [x for x, y in dataset if y == 0]
    
    n_1 = len(class_1)
    n_0 = len(class_0)
    
    # 1. Tính xác suất tiên nghiệm P(Y=1) và P(Y=0)
    p_y1 = n_1 / total_samples
    p_y0 = n_0 / total_samples
    
    # 2. Tính Likelihood P(x1|Y) và P(x2|Y) cho từng lớp
    # Với lớp Y = 1:
    p_x1_given_y1 = sum(1 for sample in class_1 if sample[0] == x_new[0]) / n_1
    p_x2_given_y1 = sum(1 for sample in class_1 if sample[1] == x_new[1]) / n_1
    
    # Với lớp Y = 0:
    p_x1_given_y0 = sum(1 for sample in class_0 if sample[0] == x_new[0]) / n_0
    p_x2_given_y0 = sum(1 for sample in class_0 if sample[1] == x_new[1]) / n_0
    
    # 3. Tính điểm xác suất hậu phương Posterior: Score(Y) = P(Y) * P(x1|Y) * P(x2|Y)
    score_y1 = p_y1 * p_x1_given_y1 * p_x2_given_y1
    score_y0 = p_y0 * p_x1_given_y0 * p_x2_given_y0
    
    print("--- CHI TIẾT TÍNH TOÁN NAIVE BAYES ---")
    print(f"P(Y=1) = {p_y1:.4f}, P(Y=0) = {p_y0:.4f}")
    print(f"P(x1={x_new[0]}|Y=1) = {p_x1_given_y1:.4f}, P(x2={x_new[1]}|Y=1) = {p_x2_given_y1:.4f}")
    print(f"P(x1={x_new[0]}|Y=0) = {p_x1_given_y0:.4f}, P(x2={x_new[1]}|Y=0) = {p_x2_given_y0:.4f}")
    print(f"Score(Y=1) = {score_y1:.4f}")
    print(f"Score(Y=0) = {score_y0:.4f}")
    
    # 4. Trả về nhãn dự đoán có Score cao hơn
    predicted_label = 1 if score_y1 >= score_y0 else 0
    return predicted_label


# Chạy thử nghiệm với test case mẫu
if __name__ == "__main__":
    dataset = [
        ([1, 1], 1),
        ([1, 0], 1),
        ([1, 1], 1),
        ([0, 1], 0),
        ([0, 0], 0),
        ([0, 0], 0)
    ]
    
    x_new = [1, 0]
    result = naive_bayes_predict(dataset, x_new)
    
    label_name = "1 (Spam)" if result == 1 else "0 (Thường)"
    print(f"\nDự đoán nhãn cho x_new = {x_new}: {label_name}")
    # Kỳ vọng trả về: 1 (Spam)
