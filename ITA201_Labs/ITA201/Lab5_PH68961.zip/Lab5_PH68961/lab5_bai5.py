"""
LAB 5 - BÀI 5: Xây dựng Pipeline Lọc Thư Rác (Spam Filtering) & Đánh giá Ma trận Nhầm lẫn
Môn học: AI21301 - Toán cho học máy
"""

import math

def extract_vocabulary(emails):
    """
    Trích xuất danh sách tất cả các từ duy nhất (Vocabulary V) từ tập dữ liệu email.
    
    Parameters:
        emails (list of tuple): Danh sách các cặp (danh_sách_từ, nhãn).
        
    Returns:
        list: Tập từ vựng V (được sắp xếp thứ tự).
    """
    vocab = set()
    for words, _ in emails:
        vocab.update(words)
    return sorted(list(vocab))


def train_naive_bayes(train_emails, alpha=1.0):
    """
    Huấn luyện mô hình Multinomial Naive Bayes với Laplace Smoothing.
    
    Parameters:
        train_emails (list of tuple): Dữ liệu huấn luyện gồm (danh_sách_từ, nhãn: 1 là Spam, 0 là Ham).
        alpha (float): Hệ số làm mượt Laplace (mặc định = 1.0).
        
    Returns:
        dict: Mô hình chứa xác suất tiên nghiệm P(Spam), P(Ham), 
              bảng xác suất điều kiện P(word|Spam), P(word|Ham) và tập từ vựng V.
    """
    total_emails = len(train_emails)
    spam_emails = [words for words, label in train_emails if label == 1]
    ham_emails = [words for words, label in train_emails if label == 0]
    
    # 1. Tính xác suất tiên nghiệm P(Spam) và P(Ham)
    p_spam = len(spam_emails) / total_emails
    p_ham = len(ham_emails) / total_emails
    
    # 2. Trích xuất từ điển V
    vocab = extract_vocabulary(train_emails)
    vocab_size = len(vocab)
    
    # 3. Đếm tần suất xuất hiện của từ trong từng lớp
    spam_word_counts = {}
    total_spam_words = 0
    for words in spam_emails:
        for w in words:
            spam_word_counts[w] = spam_word_counts.get(w, 0) + 1
            total_spam_words += 1
            
    ham_word_counts = {}
    total_ham_words = 0
    for words in ham_emails:
        for w in words:
            ham_word_counts[w] = ham_word_counts.get(w, 0) + 1
            total_ham_words += 1
            
    # 4. Tính P(word|Spam) và P(word|Ham) có áp dụng Laplace Smoothing
    p_word_given_spam = {}
    p_word_given_ham = {}
    
    for word in vocab:
        count_w_spam = spam_word_counts.get(word, 0)
        p_word_given_spam[word] = (count_w_spam + alpha) / (total_spam_words + alpha * vocab_size)
        
        count_w_ham = ham_word_counts.get(word, 0)
        p_word_given_ham[word] = (count_w_ham + alpha) / (total_ham_words + alpha * vocab_size)
        
    model = {
        'p_spam': p_spam,
        'p_ham': p_ham,
        'p_word_given_spam': p_word_given_spam,
        'p_word_given_ham': p_word_given_ham,
        'vocab': vocab
    }
    return model


def predict_email(email_words, model):
    """
    Dự đoán nhãn (1: Spam, 0: Ham) cho một email mới bằng Log-Likelihood.
    
    Parameters:
        email_words (list): Danh sách các từ trong email cần dự đoán.
        model (dict): Mô hình Naive Bayes đã huấn luyện.
        
    Returns:
        int: 1 (Spam) hoặc 0 (Ham).
    """
    # Sử dụng log-likelihood: log(P(Y)) + sum(log(P(w_i|Y)))
    log_score_spam = math.log(model['p_spam'])
    log_score_ham = math.log(model['p_ham'])
    
    for word in email_words:
        if word in model['vocab']:
            log_score_spam += math.log(model['p_word_given_spam'][word])
            log_score_ham += math.log(model['p_word_given_ham'][word])
            
    # So sánh điểm log-posterior
    print(f"Log-Score (Spam): {log_score_spam:.4f}")
    print(f"Log-Score (Ham):  {log_score_ham:.4f}")
    
    return 1 if log_score_spam >= log_score_ham else 0


# ==============================================================================
# PHÂN TÍCH Ý NGHĨA HỌC MÁY (MACHINE LEARNING INSIGHT)
# ==============================================================================
# Vì sao các kỹ sư AI dùng Log-Likelihood: log(P(Y)) + sum(log(P(w_i|Y))) 
# thay vì tính trực tiếp tích xác suất: P(Y) * P(w_1|Y) * P(w_2|Y) * ... ?
#
# 1. Hiện tượng Tràn số thực dưới (Arithmetic Underflow):
#    - Mỗi xác suất P(w_i|Y) là một giá trị rất nhỏ nằm trong khoảng (0, 1).
#    - Khi email hoặc văn bản dài gồm hàng chục hay hàng trăm từ, việc nhân liên tiếp
#      các giá trị nhỏ này sẽ dẫn đến tích số giảm theo hàm mũ, tiến cực nhanh về 0.
#    - Phần cứng máy tính biểu diễn số thực (chuẩn IEEE 754 với Float32 hoặc Float64)
#      chỉ có độ chính xác hữu hạn (ví dụ ~10^-308 đối với Double). Khi tích nhỏ hơn
#      ngưỡng tối thiểu này, giá trị bị làm tròn về 0.0 tuyệt đối (Underflow).
#      Khi đó cả Score(Spam) và Score(Ham) đều bằng 0, không thể so sánh và phân loại được.
#
# 2. Giải pháp Logarithm:
#    - Nhờ tính chất: log(a * b) = log(a) + log(b), phép nhân biến thành phép cộng các số âm.
#    - Phép cộng các giá trị logarit là hoàn toàn ổn định về mặt số học, triệt tiêu nguy cơ Underflow.
#    - Do hàm log(x) là hàm đồng biến đơn điệu trên khoảng (0, +inf), nên thứ tự so sánh
#      và việc tìm cực trị (argmax) của tổng log-xác suất hoàn toàn tương đương với tích xác suất ban đầu:
#      argmax P(Y|X) <=> argmax log P(Y|X).
# ==============================================================================


# Chạy thử nghiệm với dữ liệu bài toán
if __name__ == "__main__":
    train_emails = [
        (["free", "money", "offer"], 1),
        (["free", "ticket", "win"], 1),
        (["money", "bonus", "free"], 1),
        (["meeting", "project", "deadline"], 0),
        (["project", "report", "review"], 0),
        (["schedule", "meeting", "room"], 0)
    ]
    
    # 1. Trích xuất từ điển
    vocab = extract_vocabulary(train_emails)
    print(f"Từ điển V ({len(vocab)} từ): {vocab}\n")
    
    # 2. Huấn luyện mô hình
    model = train_naive_bayes(train_emails, alpha=1.0)
    print(f"P(Spam) = {model['p_spam']}, P(Ham) = {model['p_ham']}\n")
    
    # 3. Dự đoán email mới
    test_email = ['free', 'project', 'bonus']
    print(f"Dự đoán cho email kiểm tra: {test_email}")
    predicted_label = predict_email(test_email, model)
    
    result_str = "1 (Spam)" if predicted_label == 1 else "0 (Ham/Thường)"
    print(f"Kết quả phân loại: {result_str}")
