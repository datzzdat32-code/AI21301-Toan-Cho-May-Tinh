"""
LAB 5 - BÀI 1: Tính Shannon Entropy của Tập Dữ liệu Phân loại
Môn học: AI21301 - Toán cho học máy
"""

import math

def compute_entropy(labels):
    """
    Tính Shannon Entropy H(D) theo đơn vị bit bằng Python thuần.
    Công thức: H(D) = - sum(p_i * log2(p_i))
    
    Parameters:
        labels (list): Danh sách các nhãn phân loại.
        
    Returns:
        float: Giá trị Entropy làm tròn 4 chữ số thập phân.
    """
    # Nếu danh sách rỗng, độ hỗn loạn bằng 0
    if not labels:
        return 0.0
        
    # Bước 1: Đếm tổng số mẫu dữ liệu
    total_samples = len(labels)
    
    # Bước 2: Đếm tần suất xuất hiện của từng nhãn phân loại bằng Dictionary
    label_counts = {}
    for label in labels:
        label_counts[label] = label_counts.get(label, 0) + 1
        
    # Bước 3 & 4: Khởi tạo biến entropy = 0.0, tính xác suất p_i và cộng dồn
    entropy = 0.0
    for count in label_counts.values():
        p = count / total_samples
        if p > 0:
            entropy -= p * math.log2(p)
            
    # Bước 5: Trả về giá trị entropy làm tròn 4 chữ số thập phân
    return round(entropy, 4)


# Chạy thử nghiệm với các test case mẫu
if __name__ == "__main__":
    labels_mixed = ['Yes', 'Yes', 'No', 'Yes', 'No']  # 3 Yes, 2 No
    labels_pure = ['Yes', 'Yes', 'Yes']               # 100% Yes (tinh khiết)

    entropy_mixed = compute_entropy(labels_mixed)
    entropy_pure = compute_entropy(labels_pure)

    print(f"Entropy tập hỗn loạn (3 Yes, 2 No): {entropy_mixed} bits")
    print(f"Entropy tập tinh khiết (100% Yes): {entropy_pure} bits")

    # Kết quả kỳ vọng:
    # Tập hỗn loạn: 0.971 bits (hoặc 0.9710)
    # Tập tinh khiết: 0.0 bits
