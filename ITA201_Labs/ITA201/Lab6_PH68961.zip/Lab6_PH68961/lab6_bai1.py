"""
LAB 6 - BÀI 1: Khởi tạo và Chuyển đổi Biểu diễn Đồ thị (Ma trận kề & Danh sách kề)
Môn học: AI21301 - Toán cho học máy
"""

def build_graph_representations(num_nodes, edges):
    """
    Tạo Ma trận kề (Adjacency Matrix) kích thước N x N và 
    Danh sách kề (Adjacency List) từ danh sách các cạnh vô hướng.
    
    Parameters:
        num_nodes (int): Tổng số đỉnh của đồ thị (các đỉnh đánh số từ 0 đến N-1).
        edges (list of tuple): Danh sách các cạnh vô hướng (u, v).
        
    Returns:
        tuple: (adj_matrix, adj_list)
    """
    # Bước 1: Khởi tạo Ma trận kề N x N toàn số 0
    adj_matrix = [[0] * num_nodes for _ in range(num_nodes)]
    
    # Bước 2: Khởi tạo Danh sách kề với key từ 0 đến N-1, value là list rỗng
    adj_list = {i: [] for i in range(num_nodes)}
    
    # Bước 3: Duyệt qua từng cạnh (u, v) trong danh sách edges
    for u, v in edges:
        # Bước 4: Cập nhật Ma trận kề (đồ thị vô hướng nên đối xứng)
        adj_matrix[u][v] = 1
        adj_matrix[v][u] = 1
        
        # Bước 5: Cập nhật Danh sách kề
        adj_list[u].append(v)
        adj_list[v].append(u)
        
    # Bước 6: Trả về cặp kết quả
    return adj_matrix, adj_list


# Chạy thử nghiệm với test case mẫu
if __name__ == "__main__":
    num_nodes = 4
    edges = [(0, 1), (0, 2), (1, 2), (2, 3)]
    
    matrix, adj_list = build_graph_representations(num_nodes, edges)

    print("Ma trận kề (Adjacency Matrix):")
    for row in matrix:
        print(row)
        
    print("\nDanh sách kề (Adjacency List):")
    print(adj_list)
    
    # Kết quả kỳ vọng:
    # Ma trận:
    # [0, 1, 1, 0]
    # [1, 0, 1, 0]
    # [1, 1, 0, 1]
    # [0, 0, 1, 0]
    # Danh sách kề: {0: [1, 2], 1: [0, 2], 2: [0, 1, 3], 3: [2]}
