"""
LAB 6 - BÀI 3: Cài đặt Thuật toán Tìm kiếm theo Chiều sâu (DFS) & Phát hiện Chu trình
Môn học: AI21301 - Toán cho học máy
"""

def dfs_traversal(adj_list, start_node):
    """
    Duyệt đồ thị theo chiều sâu (DFS) sử dụng đệ quy.
    
    Parameters:
        adj_list (dict): Danh sách kề biểu diễn đồ thị.
        start_node (int): Đỉnh bắt đầu duyệt.
        
    Returns:
        list: Thứ tự các đỉnh được thăm theo DFS.
    """
    visited = set()
    traversal_order = []
    
    def dfs(u):
        visited.add(u)
        traversal_order.append(u)
        for v in adj_list.get(u, []):
            if v not in visited:
                dfs(v)
                
    dfs(start_node)
    return traversal_order


def has_cycle_undirected(adj_list, num_nodes):
    """
    Kiểm tra xem đồ thị vô hướng có chứa chu trình hay không bằng DFS.
    Trong đồ thị vô hướng, nếu gặp một đỉnh hàng xóm đã được thăm (visited)
    nhưng đỉnh đó không phải là nút cha (parent) trực tiếp vừa gọi tới,
    chứng tỏ đồ thị có chu trình.
    
    Parameters:
        adj_list (dict): Danh sách kề của đồ thị.
        num_nodes (int): Tổng số đỉnh của đồ thị (từ 0 đến num_nodes - 1).
        
    Returns:
        bool: True nếu tồn tại ít nhất một chu trình, False nếu không có.
    """
    visited = set()
    
    def dfs_cycle(u, parent):
        visited.add(u)
        for v in adj_list.get(u, []):
            # Nếu đỉnh hàng xóm chưa được thăm, tiếp tục đệ quy DFS
            if v not in visited:
                if dfs_cycle(v, u):
                    return True
            # Nếu hàng xóm đã được thăm và không phải là đỉnh cha vừa đi qua -> Chu trình phát hiện!
            elif v != parent:
                return True
        return False

    # Duyệt qua tất cả các đỉnh để đảm bảo kiểm tra hết các thành phần liên thông
    for node in range(num_nodes):
        if node not in visited:
            if dfs_cycle(node, -1):
                return True
                
    return False


# Chạy thử nghiệm với test case mẫu
if __name__ == "__main__":
    # Đồ thị có chu trình tam giác: 0 - 1 - 2 - 0
    graph_with_cycle = {0: [1, 2], 1: [0, 2], 2: [0, 1], 3: []}
    
    # Đồ thị dạng cây (không có chu trình): 0 - 1 - 3, 0 - 2
    graph_tree = {0: [1, 2], 1: [0, 3], 2: [0], 3: [1]}

    print("DFS traversal từ đỉnh 0 (graph_tree):", dfs_traversal(graph_tree, 0))
    
    cycle_1 = has_cycle_undirected(graph_with_cycle, 4)
    cycle_2 = has_cycle_undirected(graph_tree, 4)
    
    print(f"has_cycle_undirected(graph_with_cycle, 4) -> {cycle_1}") # Kỳ vọng: True
    print(f"has_cycle_undirected(graph_tree, 4) -> {cycle_2}")       # Kỳ vọng: False
