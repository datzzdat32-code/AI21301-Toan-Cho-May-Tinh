"""
LAB 6 - BÀI 4: Đếm số lượng Thành phần Liên thông & Phát hiện Cụm Dữ liệu (Connected Components)
Môn học: AI21301 - Toán cho học máy
"""

from collections import deque

def count_and_find_components(adj_list, num_nodes):
    """
    Xác định các thành phần liên thông của đồ thị vô hướng bằng thuật toán BFS/DFS.
    Trong học máy không giám sát, bài toán này tương đương với phân cụm dữ liệu
    (Graph-based Clustering) thành các cụm độc lập.
    
    Parameters:
        adj_list (dict): Danh sách kề của đồ thị.
        num_nodes (int): Tổng số đỉnh của đồ thị (từ 0 đến num_nodes - 1).
        
    Returns:
        tuple: (num_components, components)
            - num_components (int): Số lượng thành phần liên thông.
            - components (list of list): Danh sách các cụm đỉnh thuộc từng thành phần liên thông.
    """
    visited = set()
    components = []
    
    # Duyệt qua các đỉnh từ 0 đến N-1
    for start_node in range(num_nodes):
        if start_node not in visited:
            # Phát hiện một thành phần liên thông mới, dùng BFS để loang tìm toàn bộ các đỉnh trong cụm
            current_component = []
            queue = deque([start_node])
            visited.add(start_node)
            
            while queue:
                u = queue.popleft()
                current_component.append(u)
                
                for v in adj_list.get(u, []):
                    if v not in visited:
                        visited.add(v)
                        queue.append(v)
                        
            components.append(sorted(current_component))
            
    num_components = len(components)
    return num_components, components


# Chạy thử nghiệm với test case mẫu
if __name__ == "__main__":
    # Đồ thị rời rạc gồm 2 cụm: Cụm 1 {0, 1}, Cụm 2 {2, 3, 4}
    discrete_graph = {0: [1], 1: [0], 2: [3, 4], 3: [2, 4], 4: [2, 3]}
    num_nodes = 5
    
    num_comps, comp_list = count_and_find_components(discrete_graph, num_nodes)
    
    print(f"Số thành phần liên thông: {num_comps}")
    print(f"Danh sách cụm: {comp_list}")
    
    # Kết quả kỳ vọng:
    # Số thành phần liên thông: 2
    # Danh sách cụm: [[0, 1], [2, 3, 4]]
