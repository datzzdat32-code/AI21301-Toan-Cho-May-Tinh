"""
LAB 6 - BÀI 2: Cài đặt Thuật toán Tìm kiếm theo Chiều rộng (BFS) Tìm Đường đi Ngắn nhất
Môn học: AI21301 - Toán cho học máy
"""

from collections import deque

def bfs_shortest_path(adj_list, start_node):
    """
    Thuật toán duyệt BFS trên đồ thị không có trọng số để tìm thứ tự duyệt
    và khoảng cách ngắn nhất (số cạnh tối thiểu) từ start_node đến các đỉnh khác.
    
    Parameters:
        adj_list (dict): Danh sách kề biểu diễn đồ thị.
        start_node (int): Đỉnh nguồn bắt đầu duyệt.
        
    Returns:
        tuple: (traversal_order, dist)
            - traversal_order (list): Thứ tự các đỉnh được duyệt qua.
            - dist (dict): Khoảng cách ngắn nhất từ start_node đến từng đỉnh đến được.
    """
    # Bước 1 & 2: Khởi tạo tập visited, từ điển khoảng cách dist và hàng đợi Queue
    visited = set([start_node])
    dist = {start_node: 0}
    queue = deque([start_node])
    traversal_order = []
    
    # Bước 3: Vòng lặp lấy đỉnh ra khỏi Queue
    while queue:
        u = queue.popleft()
        traversal_order.append(u)
        
        # Bước 4: Duyệt qua các hàng xóm kề với u
        for v in adj_list.get(u, []):
            if v not in visited:
                visited.add(v)
                dist[v] = dist[u] + 1
                queue.append(v)
                
    return traversal_order, dist


# Chạy thử nghiệm với test case mẫu
if __name__ == "__main__":
    graph = {0: [1, 2], 1: [0, 3], 2: [0], 3: [1]}
    
    order, distances = bfs_shortest_path(graph, 0)
    
    print("Thứ tự duyệt BFS:", order)
    print("Khoảng cách từ đỉnh 0:", distances)
    
    # Kết quả kỳ vọng:
    # Thứ tự duyệt BFS: [0, 1, 2, 3]
    # Khoảng cách từ đỉnh 0: {0: 0, 1: 1, 2: 1, 3: 2}
