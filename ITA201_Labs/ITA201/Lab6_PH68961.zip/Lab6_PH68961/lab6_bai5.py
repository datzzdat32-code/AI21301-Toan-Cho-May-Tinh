"""
LAB 6 - BÀI 5: Thuật toán Loang màu Phân vùng Ảnh (Flood Fill Algorithm) trên Ma trận Pixel 2D
Môn học: AI21301 - Toán cho học máy
"""

from collections import deque

def flood_fill_bfs(image, start_row, start_col, new_color):
    """
    Cài đặt thuật toán Flood Fill bằng tìm kiếm theo chiều rộng (BFS).
    Đổi màu của pixel gốc (start_row, start_col) và tất cả các pixel liên thông
    4 hướng (Trên, Dưới, Trái, Phải) có cùng màu ban đầu sang new_color.
    
    Parameters:
        image (list of list): Ma trận ảnh 2D kích thước M x N.
        start_row (int): Chỉ số hàng của pixel bắt đầu.
        start_col (int): Chỉ số cột của pixel bắt đầu.
        new_color (int): Giá trị màu mới cần tô.
        
    Returns:
        list of list: Ma trận ảnh sau khi đã loang màu.
    """
    if not image or not image[0]:
        return image
        
    m = len(image)
    n = len(image[0])
    
    original_color = image[start_row][start_col]
    
    # Xử lý điều kiện biên & tránh vòng lặp vô hạn:
    # Nếu màu mới trùng với màu ban đầu, không cần thay đổi gì
    if original_color == new_color:
        return image
        
    # Tạo bản sao độc lập của ảnh để không làm thay đổi trực tiếp biến đầu vào nếu muốn
    result_image = [row[:] for row in image]
    
    # 4 hướng di chuyển: Trên, Dưới, Trái, Phải
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    
    queue = deque([(start_row, start_col)])
    result_image[start_row][start_col] = new_color
    
    while queue:
        r, c = queue.popleft()
        
        for dr, dc in directions:
            nr = r + dr
            nc = c + dc
            
            # Kiểm tra điều kiện biên và cùng màu ban đầu
            if 0 <= nr < m and 0 <= nc < n and result_image[nr][nc] == original_color:
                result_image[nr][nc] = new_color
                queue.append((nr, nc))
                
    return result_image


# ==============================================================================
# PHÂN TÍCH ĐỘ PHỨC TẠP THUẬT TOÁN (COMPLEXITY ANALYSIS)
# ==============================================================================
# 1. Độ phức tạp thời gian (Time Complexity):
#    - O(M x N), trong đó M là số hàng và N là số cột của ma trận ảnh.
#    - Trong trường hợp xấu nhất (toàn bộ điểm ảnh trong ma trận có cùng một màu ban đầu),
#      mỗi pixel được đưa vào và lấy ra khỏi hàng đợi BFS đúng 1 lần.
#    - Tại mỗi pixel, ta chỉ duyệt qua 4 hướng lân cận (hằng số c = 4).
#    - Do đó tổng số phép tính tỉ lệ thuận với số lượng pixel: O(4 * M * N) = O(M x N).
#
# 2. Độ phức tạp không gian (Space Complexity):
#    - O(M x N).
#    - Trong trường hợp xấu nhất, hàng đợi BFS (Queue) cần lưu các pixel đang chờ duyệt
#      ở đường biên của vùng loang. Độ dài lớn nhất của hàng đợi bị chặn trên bởi O(M x N).
#
# 3. Vì sao lưới pixel 2D tương đương đồ thị phẳng có bậc tối đa bằng 4?
#    - Mỗi pixel (r, c) trong lưới 4-kết nối chỉ có tối đa 4 điểm ảnh lân cận trực tiếp:
#        + Trên:  (r - 1, c)
#        + Dưới:  (r + 1, c)
#        + Trái:  (r, c - 1)
#        + Phải:  (r, c + 1)
#    - Các pixel ở 4 góc có bậc bằng 2, các pixel ở cạnh biên có bậc bằng 3,
#      và các pixel nằm bên trong lưới có bậc đúng bằng 4.
#    - Do không có bất kỳ đỉnh nào có nhiều hơn 4 cạnh nối, nên bậc tối đa (Maximum Degree)
#      của đồ thị là Delta(G) = 4.
#    - Các cạnh nối giữa 4 pixel lân cận trên mặt phẳng 2D có thể vẽ mà không cắt nhau,
#      thỏa mãn định nghĩa hình học của một Đồ thị phẳng (Planar Graph).
# ==============================================================================


# Chạy thử nghiệm với test case mẫu
if __name__ == "__main__":
    image = [
        [1, 1, 1, 0, 0],
        [1, 1, 0, 0, 2],
        [1, 0, 0, 2, 2],
        [0, 0, 2, 2, 2]
    ]

    print("--- Ma trận ảnh ban đầu ---")
    for row in image:
        print(row)

    # Test case 1: Tô màu vùng pixel 1 bắt đầu từ tọa độ (0, 0) sang màu mới 9
    filled_image = flood_fill_bfs(image, start_row=0, start_col=0, new_color=9)
    print("\n--- Ảnh sau khi Flood Fill từ (0, 0) sang màu 9 ---")
    for row in filled_image:
        print(row)

    # Test case 2: Tô màu vùng pixel 2 bắt đầu từ tọa độ (3, 4) sang màu mới 7
    filled_image_2 = flood_fill_bfs(image, start_row=3, start_col=4, new_color=7)
    print("\n--- Ảnh sau khi Flood Fill từ (3, 4) sang màu 7 ---")
    for row in filled_image_2:
        print(row)
